<?php // admin/footer.php ?>
        </main> <!-- /.admin-content -->

    </div> <!-- /.admin-layout -->

    <footer class="admin-footer">
        <span>Gamemoira Admin &copy; <?= date('Y') ?></span>
    </footer>

</div> <!-- /.admin-root -->

</body>
</html>
