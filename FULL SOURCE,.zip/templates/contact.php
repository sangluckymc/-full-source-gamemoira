<?php
$pageTitle = 'Liên hệ';
$metaDescription = 'Liên hệ Gamemoira Pro để được tư vấn và hỗ trợ triển khai.';

$success = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $phone     = trim($_POST['phone'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $message   = trim($_POST['message'] ?? '');

    if ($full_name === '' || $message === '') {
        $error = 'Vui lòng nhập họ tên và nội dung.';
    } else {
        $stmt = $pdo->prepare("INSERT INTO contacts (full_name, phone, email, message) VALUES (?, ?, ?, ?)");
        $stmt->execute([$full_name, $phone, $email, $message]);
        $success = 'Gửi liên hệ thành công. Chúng tôi sẽ phản hồi sớm nhất.';
    }
}
?>

<div class="container my-4">
    <h1 class="h4 mb-3">Liên hệ Gamemoira Pro</h1>

    <div class="row gy-4">
        <div class="col-md-6">
            <?php if ($success): ?>
                <div class="alert alert-success"><?= e($success) ?></div>
            <?php elseif ($error): ?>
                <div class="alert alert-danger"><?= e($error) ?></div>
            <?php endif; ?>

            <form method="post" novalidate>
                <div class="mb-3">
                    <label class="form-label">Họ tên *</label>
                    <input type="text" name="full_name" class="form-control" required
                           value="<?= e($_POST['full_name'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Số điện thoại</label>
                    <input type="text" name="phone" class="form-control"
                           value="<?= e($_POST['phone'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control"
                           value="<?= e($_POST['email'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Nội dung *</label>
                    <textarea name="message" rows="5" class="form-control" required><?= e($_POST['message'] ?? '') ?></textarea>
                </div>
                <button class="btn btn-primary">Gửi liên hệ</button>
            </form>
        </div>

        <div class="col-md-6">
            <h2 class="h6">Thông tin công ty</h2>
            <p class="small mb-2">
                Địa chỉ: (cập nhật)<br>
                Số điện thoại: (cập nhật)<br>
                Email: contact@gamemoira.vn
            </p>
            <p class="small mb-2">
                Kết nối:
                <a href="#" class="link-primary">Facebook</a> ·
                <a href="#" class="link-primary">Zalo</a> ·
                <a href="#" class="link-primary">LinkedIn</a>
            </p>
        </div>
    </div>
</div>
