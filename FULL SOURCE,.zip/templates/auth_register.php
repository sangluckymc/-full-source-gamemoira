<?php
// auth_register.php
// Trang Đăng ký tài khoản (UI đẹp giống ảnh mẫu)

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle       = 'Đăng ký tài khoản';
$metaDescription = 'Đăng ký tài khoản thành viên Gamemoira.vn';

$errors  = [];
$success = '';

$full_name        = trim($_POST['full_name']        ?? '');
$email            = trim($_POST['email']            ?? '');
$phone            = trim($_POST['phone']            ?? '');
$password         = trim($_POST['password']         ?? '');
$password_confirm = trim($_POST['password_confirm'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($full_name === '') {
        $errors[] = 'Vui lòng nhập họ và tên.';
    }

    if ($email === '') {
        $errors[] = 'Vui lòng nhập địa chỉ Email.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email không hợp lệ.';
    }

    if ($phone === '') {
        $errors[] = 'Vui lòng nhập số điện thoại.';
    } elseif (!preg_match('/^[0-9]{8,15}$/', $phone)) {
        $errors[] = 'Số điện thoại chỉ gồm 8–15 chữ số.';
    }

    if ($password === '') {
        $errors[] = 'Vui lòng nhập mật khẩu.';
    } elseif (mb_strlen($password) < 6) {
        $errors[] = 'Mật khẩu phải từ 6 ký tự trở lên.';
    }

    if ($password_confirm === '') {
        $errors[] = 'Vui lòng nhập lại mật khẩu.';
    } elseif ($password !== $password_confirm) {
        $errors[] = 'Mật khẩu nhập lại không khớp.';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare("
                SELECT id 
                FROM users 
                WHERE email = :email OR phone = :phone
                LIMIT 1
            ");
            $stmt->execute([
                ':email' => $email,
                ':phone' => $phone,
            ]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                $errors[] = 'Email hoặc Số điện thoại đã được sử dụng, vui lòng chọn thông tin khác.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);

                $stmt = $pdo->prepare("
                    INSERT INTO users (full_name, email, phone, password_hash, gold, created_at)
                    VALUES (:full_name, :email, :phone, :password_hash, 0, NOW())
                ");
                $stmt->execute([
                    ':full_name'     => $full_name,
                    ':email'         => $email,
                    ':phone'         => $phone,
                    ':password_hash' => $hash,
                ]);

                $userId = $pdo->lastInsertId();
                $_SESSION['user_id'] = $userId;

                $success  = 'Đăng ký thành công! Hệ thống sẽ chuyển bạn sang trang chủ.';
                $full_name        = '';
                $email            = '';
                $phone            = '';
                $password         = '';
                $password_confirm = '';

                header("Refresh: 2; url=" . BASE_URL);
            }
        } catch (Exception $e) {
            $errors[] = 'Lỗi hệ thống: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/header.php';
?>

<div class="auth-page">
    <div class="auth-card">
        <h1 class="auth-title">Đăng ký</h1>

        <?php if ($errors): ?>
            <div class="auth-alert auth-alert-danger">
                <?php foreach ($errors as $err): ?>
                    <div>- <?= e($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php elseif ($success): ?>
            <div class="auth-alert auth-alert-success">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <form action="" method="post" class="auth-form">

            <div class="auth-form-group">
                <input type="text"
                       name="full_name"
                       class="auth-input"
                       placeholder="Nhập họ và tên"
                       value="<?= e($full_name) ?>"
                       required>
            </div>

            <div class="auth-form-group">
                <input type="email"
                       name="email"
                       class="auth-input"
                       placeholder="Nhập địa chỉ Email"
                       value="<?= e($email) ?>"
                       required>
            </div>

            <div class="auth-form-group">
                <input type="text"
                       name="phone"
                       class="auth-input"
                       placeholder="Nhập số điện thoại"
                       value="<?= e($phone) ?>"
                       required>
            </div>

            <div class="auth-form-group">
                <input type="password"
                       name="password"
                       class="auth-input"
                       placeholder="Nhập mật khẩu"
                       required>
            </div>

            <div class="auth-form-group">
                <input type="password"
                       name="password_confirm"
                       class="auth-input"
                       placeholder="Nhập lại mật khẩu"
                       required>
            </div>

            <button type="submit" class="auth-btn auth-btn-primary">
                Đăng ký
            </button>
        </form>

        <div class="auth-helper">
            Đã có tài khoản?
        </div>

        <div class="auth-divider-text">hoặc</div>

        <form action="<?= BASE_URL ?>templates/login.php" method="get">
            <button type="submit" class="auth-btn-login">
                Đăng nhập
            </button>
        </form>

        <!-- MỤC QUÊN MẬT KHẨU MỚI THÊM -->
        <div class="auth-helper auth-helper-forgot">
            <a href="<?= BASE_URL ?>templates/auth_forgot.php" class="auth-link-forgot">
                Quên mật khẩu?
            </a>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
