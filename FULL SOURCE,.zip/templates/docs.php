<?php
$pageTitle = 'Tài liệu / Hướng dẫn sử dụng Gamemoira Pro';
$metaDescription = 'Tài liệu PDF, video tutorial, FAQ cho người mới sử dụng Gamemoira Pro.';

$docsStmt = $pdo->query("SELECT * FROM documents ORDER BY id DESC");
$docs = $docsStmt->fetchAll();

$byType = [
    'beginner' => [],
    'faq'      => [],
    'video'    => [],
];

foreach ($docs as $d) {
    $byType[$d['doc_type']][] = $d;
}
?>

<div class="container my-4">
    <h1 class="h4 mb-3">Tài liệu / Hướng dẫn sử dụng Gamemoira Pro</h1>

    <!-- Hướng dẫn cho người mới -->
    <section class="mb-4">
        <h2 class="h5 mb-2">Hướng dẫn cho người mới</h2>
        <?php if ($byType['beginner']): ?>
            <ul class="list-group">
                <?php foreach ($byType['beginner'] as $doc): ?>
                    <li class="list-group-item">
                        <strong><?= e($doc['title']) ?></strong><br>
                        <?php if (!empty($doc['description'])): ?>
                            <span class="small d-block mb-1"><?= e($doc['description']) ?></span>
                        <?php endif; ?>
                        <?php if (!empty($doc['file_url'])): ?>
                            <a href="<?= BASE_URL . e($doc['file_url']) ?>" target="_blank" class="small">
                                Tải tài liệu (PDF)
                            </a>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="text-muted small">Đang cập nhật...</p>
        <?php endif; ?>
    </section>

    <!-- FAQ -->
    <section class="mb-4">
        <h2 class="h5 mb-2">FAQ thường gặp</h2>
        <?php if ($byType['faq']): ?>
            <ul class="list-group">
                <?php foreach ($byType['faq'] as $doc): ?>
                    <li class="list-group-item">
                        <strong><?= e($doc['title']) ?></strong><br>
                        <?php if (!empty($doc['description'])): ?>
                            <span class="small d-block mb-1"><?= nl2br(e($doc['description'])) ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="text-muted small">Đang cập nhật...</p>
        <?php endif; ?>
    </section>

    <!-- Video tutorial -->
    <section>
        <h2 class="h5 mb-2">Video tutorial</h2>
        <?php if ($byType['video']): ?>
            <div class="row gy-3">
                <?php foreach ($byType['video'] as $doc): ?>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <strong><?= e($doc['title']) ?></strong><br>
                                <?php if (!empty($doc['description'])): ?>
                                    <p class="small mb-2"><?= e($doc['description']) ?></p>
                                <?php endif; ?>
                                <?php if (!empty($doc['video_url'])): ?>
                                    <?php if (str_contains($doc['video_url'], 'youtube.com') || str_contains($doc['video_url'], 'youtu.be')): ?>
                                        <a href="<?= e($doc['video_url']) ?>" target="_blank" class="small">
                                            Xem video trên YouTube
                                        </a>
                                    <?php else: ?>
                                        <video class="w-100 mt-2" controls>
                                            <source src="<?= BASE_URL . e($doc['video_url']) ?>" type="video/mp4">
                                        </video>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-muted small">Đang cập nhật...</p>
        <?php endif; ?>
    </section>
</div>
