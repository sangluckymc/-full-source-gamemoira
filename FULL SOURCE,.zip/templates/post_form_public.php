<?php
// Trang đăng bài giới thiệu Game mới (public)
// Lưu dữ liệu vào bảng game_submissions cho Admin duyệt

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Đăng bài giới thiệu Game mới';

// Giá GOLD phải trừ khi submit bài VIP
define('SUBMIT_COST_GOLD', 20);

$errors = [];
$success = '';

$isLoggedIn = !empty($_SESSION['user_id']);
$userId     = $isLoggedIn ? (int)$_SESSION['user_id'] : 0;

function gm_field($name) {
    return trim($_POST[$name] ?? '');
}

// Tạo slug đơn giản từ tên game
function gm_make_post_slug($str) {
    $str = strtolower(trim($str));
    // thay khoảng trắng bằng -
    $str = preg_replace('/\s+/', '-', $str);
    // chỉ giữ lại a-z0-9-
    $str = preg_replace('/[^a-z0-9\-]/', '', $str);
    if ($str === '') {
        $str = 'game-' . time();
    }
    return $str;
}

// Tạo nội dung HTML cho bài post (Hiển thị Game)
function gm_build_post_content($data) {
    $homepage    = $data['homepage'];
    $fanpage     = $data['fanpage'];
    $version     = $data['version'];
    $reset_type  = $data['reset_type'];
    $category    = $data['category'];
    $point_type  = $data['point_type'];
    $server_name = $data['server_name'];
    $alpha_time  = $data['alpha_time'];
    $alpha_date  = $data['alpha_date'];
    $open_time   = $data['open_time'];
    $open_date   = $data['open_date'];
    $exp_rate    = $data['exp_rate'];
    $drop_rate   = $data['drop_rate'];
    $anti_hack   = $data['anti_hack'];
    $banner      = $data['banner'];
    $content     = $data['content'];
    $game_name   = $data['game_name'];

    $h = function($s) {
        return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    };

    $html  = '<p><strong>Trang chủ:</strong> <a href="' . $h($homepage) . '" target="_blank">' . $h($homepage) . '</a></p>';
    if ($fanpage !== '') {
        $html .= '<p><strong>Fanpage / Group:</strong> ' . $h($fanpage) . '</p>';
    }
    $html .= '<p><strong>Phiên bản:</strong> ' . $h($version)
          . ' &nbsp; | &nbsp; <strong>Kiểu reset:</strong> ' . $h($reset_type) . '</p>';
    $html .= '<p><strong>Thể loại:</strong> ' . $h($category)
          . ' &nbsp; | &nbsp; <strong>Kiểu point:</strong> ' . $h($point_type) . '</p>';
    $html .= '<p><strong>Máy chủ:</strong> ' . $h($server_name) . '</p>';
    if ($alpha_time !== '' || $alpha_date !== '') {
        $html .= '<p><strong>Alpha Test:</strong> ' . $h(trim($alpha_time . ' - ' . $alpha_date)) . '</p>';
    }
    if ($open_time !== '' || $open_date !== '') {
        $html .= '<p><strong>Open Beta:</strong> ' . $h(trim($open_time . ' - ' . $open_date)) . '</p>';
    }
    if ($exp_rate !== '' || $drop_rate !== '') {
        $html .= '<p><strong>Exp rate:</strong> ' . $h($exp_rate)
              . ' &nbsp; | &nbsp; <strong>Drop rate:</strong> ' . $h($drop_rate) . '</p>';
    }
    if ($anti_hack !== '') {
        $html .= '<p><strong>Anti Hack:</strong> ' . $h($anti_hack) . '</p>';
    }

    if ($banner !== '') {
        $html .= '<p><strong>Banner:</strong><br>';
        $html .= '<img src="' . $h($banner) . '" alt="' . $h($game_name) . '" style="max-width:100%;height:auto;">';
        $html .= '</p>';
    }

    $html .= '<hr><div>' . nl2br($h($content)) . '</div>';

    return $html;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!$isLoggedIn) {
        $errors[] = 'Bạn cần đăng nhập trước khi đăng bài giới thiệu Game.';
    } else {

        // ==========================
        // LẤY DỮ LIỆU TỪ FORM
        // ==========================
        $note        = gm_field('note');
        $post_type   = gm_field('post_type'); // thuong | vip
        $game_name   = gm_field('game_name');
        $homepage    = gm_field('homepage');
        $fanpage     = gm_field('fanpage');

        $version     = gm_field('version');
        $reset_type  = gm_field('reset_type');
        $category    = gm_field('category');
        $point_type  = gm_field('point_type');

        $server_name = gm_field('server_name');
        $short_desc  = gm_field('short_desc');

        $alpha_time  = gm_field('alpha_time');
        $alpha_date  = gm_field('alpha_date');
        $open_time   = gm_field('open_time');
        $open_date   = gm_field('open_date');

        $exp_rate    = gm_field('exp_rate');
        $drop_rate   = gm_field('drop_rate');
        $anti_hack   = gm_field('anti_hack');

        $content     = $_POST['content'] ?? '';
        $image_url_input = gm_field('image_url');

        $isVip = ($post_type === 'vip');

        // ==========================
        // VALIDATE CƠ BẢN
        // ==========================
        if ($game_name === '')  $errors[] = 'Vui lòng nhập Tên Game.';
        if ($homepage === '')   $errors[] = 'Vui lòng nhập Trang chủ Game.';
        if ($version === '')    $errors[] = 'Vui lòng chọn Phiên bản Game.';
        if ($reset_type === '') $errors[] = 'Vui lòng chọn Kiểu reset.';
        if ($category === '')   $errors[] = 'Vui lòng chọn Thể loại Game.';
        if ($point_type === '') $errors[] = 'Vui lòng chọn Kiểu point.';
        if ($server_name === '')$errors[] = 'Vui lòng nhập Tên máy chủ.';
        if ($short_desc === '') $errors[] = 'Vui lòng nhập mô tả ngắn.';
        if ($exp_rate === '')   $errors[] = 'Vui lòng nhập Exp rate.';
        if ($drop_rate === '')  $errors[] = 'Vui lòng nhập Drop rate.';
        if (trim($content) === '') $errors[] = 'Vui lòng nhập mô tả chi tiết.';

        if (empty($_POST['captcha']) || strtoupper(trim($_POST['captcha'])) !== 'GAME') {
            $errors[] = 'Vui lòng nhập đúng mã xác nhận GAME.';
        }

        // ==========================
        // XỬ LÝ UPLOAD
        // ==========================
        $final_media_url = '';
        $upload_error    = '';

        if (!empty($_FILES['media_file']['name'])) {

            if ($_FILES['media_file']['error'] === UPLOAD_ERR_OK) {

                $tmpName  = $_FILES['media_file']['tmp_name'];
                $origName = $_FILES['media_file']['name'];
                $size     = (int)$_FILES['media_file']['size'];

                if ($size > 50 * 1024 * 1024) {
                    $upload_error = 'File upload quá lớn (tối đa 50MB).';
                } else {
                    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
                    $allowed = ['jpg','jpeg','png','gif','webp','mp4'];

                    if (!in_array($ext, $allowed, true)) {
                        $upload_error = 'Định dạng file không hợp lệ.';
                    } else {
                        $rootDir    = dirname(__DIR__);
                        $uploadDir  = $rootDir . '/assets/uploads';

                        if (!is_dir($uploadDir)) {
                            @mkdir($uploadDir, 0777, true);
                        }

                        $newName   = 'gm_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                        $targetAbs = $uploadDir . '/' . $newName;

                        if (move_uploaded_file($tmpName, $targetAbs)) {
                            $final_media_url = 'assets/uploads/' . $newName;
                        } else {
                            $upload_error = 'Không thể lưu file upload.';
                        }
                    }
                }
            } else {
                $upload_error = 'Có lỗi khi upload file.';
            }

            if ($upload_error !== '') {
                $errors[] = $upload_error;
            }
        }

        if ($final_media_url === '' && $image_url_input !== '') {
            $final_media_url = $image_url_input;
        }

        if ($final_media_url === '' && empty($_FILES['media_file']['name'])) {
            $errors[] = 'Vui lòng úp ảnh/video hoặc nhập link.';
        }

        // ==========================
        // BLOCK: TRỪ GOLD + LƯU GIAO DỊCH + INSERT DB
        // ==========================
        if (!$errors) {
            try {
                $pdo->beginTransaction();

                // Nếu là VIP thì kiểm tra GOLD, còn tin thường thì miễn phí
                $currentGold = 0;

                if ($isVip) {
                    // Lấy GOLD hiện tại (FOR UPDATE để khóa)
                    $stmt = $pdo->prepare("SELECT gold FROM users WHERE id = :id FOR UPDATE");
                    $stmt->execute([':id' => $userId]);
                    $u = $stmt->fetch(PDO::FETCH_ASSOC);

                    if (!$u) {
                        throw new Exception('Không tìm thấy user.');
                    }

                    $currentGold = (int)$u['gold'];

                    if ($currentGold < SUBMIT_COST_GOLD) {
                        $pdo->rollBack();
                        $errors[] = "Bạn không đủ GOLD để đăng tin VIP. Cần ".SUBMIT_COST_GOLD." GOLD.";
                        // Thoát khỏi khối try
                        goto END_PROCESS;
                    }

                    // TRỪ GOLD CHO VIP
                    $stmt = $pdo->prepare("
                        UPDATE users 
                        SET gold = gold - :cost 
                        WHERE id = :id
                    ");
                    $stmt->execute([
                        ':cost' => SUBMIT_COST_GOLD,
                        ':id'   => $userId,
                    ]);
                }

                // Nếu VIP -> tạo luôn bài viết trong posts
                $postId = null;
                if ($isVip) {
                    $slug = gm_make_post_slug($game_name);

                    $postContent = gm_build_post_content([
                        'homepage'    => $homepage,
                        'fanpage'     => $fanpage,
                        'version'     => $version,
                        'reset_type'  => $reset_type,
                        'category'    => $category,
                        'point_type'  => $point_type,
                        'server_name' => $server_name,
                        'alpha_time'  => $alpha_time,
                        'alpha_date'  => $alpha_date,
                        'open_time'   => $open_time,
                        'open_date'   => $open_date,
                        'exp_rate'    => $exp_rate,
                        'drop_rate'   => $drop_rate,
                        'anti_hack'   => $anti_hack,
                        'banner'      => $final_media_url,
                        'content'     => $content,
                        'game_name'   => $game_name,
                    ]);

                    $stmt = $pdo->prepare("
                        INSERT INTO posts
                        (title, slug, excerpt, content, type, status, thumbnail,
                         user_id, category_id, meta_title, meta_description,
                         created_at, published_at)
                        VALUES
                        (:title, :slug, :excerpt, :content, 'vip', 'published', :thumbnail,
                         :user_id, NULL, :meta_title, :meta_description,
                         NOW(), NOW())
                    ");

                    $stmt->execute([
                        ':title'            => $game_name,
                        ':slug'             => $slug,
                        ':excerpt'          => $short_desc,
                        ':content'          => $postContent,
                        ':thumbnail'        => $final_media_url,
                        ':user_id'          => $userId,
                        ':meta_title'       => $game_name,
                        ':meta_description' => $short_desc,
                    ]);

                    $postId = (int)$pdo->lastInsertId();
                }

                // LƯU BÀI VÀO game_submissions
                $stmt = $pdo->prepare("
                    INSERT INTO game_submissions
                    (note, game_name, image_url, homepage, fanpage,
                     version, reset_type, category, point_type,
                     server_name, short_desc,
                     alpha_time, alpha_date, open_time, open_date,
                     exp_rate, drop_rate, anti_hack,
                     content, post_id, status, created_at)
                    VALUES
                    (:note, :game_name, :image_url, :homepage, :fanpage,
                     :version, :reset_type, :category, :point_type,
                     :server_name, :short_desc,
                     :alpha_time, :alpha_date, :open_time, :open_date,
                     :exp_rate, :drop_rate, :anti_hack,
                     :content, :post_id, :status, NOW())
                ");

                // Gắn loại tin vào ghi chú để Admin dễ thấy
                $post_type_clean = $isVip ? 'vip' : 'thuong';
                if ($isVip) {
                    $notePrefix = '[VIP] ';
                } else {
                    $notePrefix = '[Thường] ';
                }
                $note = $notePrefix . $note;

                $status = $isVip ? 'approved' : 'pending';

                $stmt->execute([
                    ':note'        => $note,
                    ':game_name'   => $game_name,
                    ':image_url'   => $final_media_url,
                    ':homepage'    => $homepage,
                    ':fanpage'     => $fanpage,
                    ':version'     => $version,
                    ':reset_type'  => $reset_type,
                    ':category'    => $category,
                    ':point_type'  => $point_type,
                    ':server_name' => $server_name,
                    ':short_desc'  => $short_desc,
                    ':alpha_time'  => $alpha_time,
                    ':alpha_date'  => $alpha_date,
                    ':open_time'   => $open_time,
                    ':open_date'   => $open_date,
                    ':exp_rate'    => $exp_rate,
                    ':drop_rate'   => $drop_rate,
                    ':anti_hack'   => $anti_hack,
                    ':content'     => $content,
                    ':post_id'     => $postId,
                    ':status'      => $status,
                ]);

                $submissionId = $pdo->lastInsertId();

                // Nếu VIP thì lưu giao dịch GOLD
                if ($isVip) {
                    $stmt = $pdo->prepare("
                        INSERT INTO transactions
                        (user_id, type, gold, note, created_at)
                        VALUES (:uid, 'dang_game_vip', :gold, :note, NOW())
                    ");

                    $stmt->execute([
                        ':uid'  => $userId,
                        ':gold' => -SUBMIT_COST_GOLD,
                        ':note' => 'Đăng Game VIP #' . $submissionId
                    ]);
                }

                $pdo->commit();

                if ($isVip) {
                    $success = "Gửi bài VIP thành công! Bạn đã bị trừ ".SUBMIT_COST_GOLD." GOLD và bài đã hiển thị ngay.";
                } else {
                    $success = "Gửi bài thường thành công! Bài sẽ được Admin duyệt trước khi hiển thị. Bạn không bị trừ GOLD.";
                }
                $_POST   = [];

            END_PROCESS:
                // nhãn goto
                ;
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $errors[] = 'Lỗi hệ thống: ' . $e->getMessage();
            }
        }
    }
}

// ----------------------------
// HTML VIEW
// ----------------------------
require_once __DIR__ . "/header.php";

$currentPath   = $_SERVER['REQUEST_URI'] ?? '/';
$redirectParam = urlencode($currentPath);

$loginUrl    = BASE_URL . 'dang-nhap?redirect=' . $redirectParam;
$registerUrl = BASE_URL . 'dang-ky';
$forgotUrl   = BASE_URL . 'quen-mat-khau';
?>

<div class="gm-form-page">
    <div class="gm-form-card">

        <h1 class="gm-form-title">Đăng bài giới thiệu Game mới</h1>

        <?php if ($errors): ?>
            <div class="gm-alert gm-alert-danger">
                <?php foreach ($errors as $err): ?>
                    <div>- <?= e($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php elseif ($success): ?>
            <div class="gm-alert gm-alert-success">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <?php if (!$isLoggedIn): ?>
            <div class="gm-alert gm-alert-info">
                Bạn cần <b>đăng nhập</b> để đăng Game mới.
            </div>

            <div class="gm-auth-actions">
                <a href="<?= $loginUrl ?>" class="gm-btn-submit">Đăng nhập</a>
                <a href="<?= $registerUrl ?>" class="gm-btn-secondary">Đăng ký</a>
                <a href="<?= $forgotUrl ?>" class="gm-btn-link">Quên mật khẩu</a>
            </div>

        <?php else: ?>

            <form method="post" action="" enctype="multipart/form-data" class="gm-form">

                <!-- GHI CHÚ CHO ADMIN -->
                <div class="gm-form-section">
                    <h2 class="gm-form-section-title">GHI CHÚ CHO ADMIN</h2>
                    <p class="gm-help">
                        Ghi chú nội bộ (không bắt buộc điền).
                    </p>
                    <div class="gm-form-row">
                        <textarea name="note" rows="2" class="gm-input gm-textarea"
                                  placeholder="Ví dụ: ưu tiên đăng sớm, có event tặng giftcode cho người chơi..."><?= e($_POST['note'] ?? '') ?></textarea>
                    </div>
                </div>

                <!-- HÌNH ẢNH / VIDEO GAME -->
                <div class="gm-form-section">
                    <h2 class="gm-form-section-title">HÌNH ẢNH / VIDEO GAME *</h2>

                    <div class="gm-form-row gm-form-row-inline">
                        <div>
                            <label>Upload hình / video <span class="gm-required">*</span></label>
                            <input type="file" name="media_file" class="gm-input"
                                   accept="image/*,video/*">
                            <p class="gm-help">
                                Ảnh/Video hỗ trợ: *.jpg, *.jpeg, *.gif, *.png, *.mp4.
                            </p>
                        </div>
                        <div>
                            <label>Hoặc link hình ảnh / video ngoài <span class="gm-required">*</span></label>
                            <input type="text" name="image_url" class="gm-input"
                                   placeholder="Ví dụ: https://i.imgur.com/... hoặc link video YouTube..."
                                   value="<?= e($_POST['image_url'] ?? '') ?>">
                            <p class="gm-help">
                                Kích thước gợi ý: 780x110 (banner ngang).
                            </p>
                        </div>
                    </div>
                </div>

                <!-- THÔNG TIN CHÍNH -->
                <div class="gm-form-section">
                    <h2 class="gm-form-section-title">THÔNG TIN CHÍNH *</h2>

                    <div class="gm-form-row">
                        <label>Tên Game <span class="gm-required">*</span></label>
                        <input type="text" name="game_name" class="gm-input"
                               placeholder="Tên Game mới (vd: Game Về Bình)"
                               value="<?= e($_POST['game_name'] ?? '') ?>" required>
                    </div>

                    <div class="gm-form-row">
                        <label>Loại tin đăng</label>
                        <div class="gm-radio-group">
                            <?php $post_type_val = $_POST['post_type'] ?? 'thuong'; ?>
                            <label class="gm-radio-option">
                                <input type="radio" name="post_type" value="thuong"
                                       <?= $post_type_val === 'vip' ? '' : 'checked' ?>>
                                Đăng tin thường (miễn phí, cần Admin duyệt)
                            </label>
                            <label class="gm-radio-option">
                                <input type="radio" name="post_type" value="vip"
                                       <?= $post_type_val === 'vip' ? 'checked' : '' ?>>
                                Đăng tin VIP (trừ <?= SUBMIT_COST_GOLD ?> GOLD, hiển thị ngay)
                            </label>
                        </div>
                    </div>

                    <div class="gm-form-row">
                        <label>Trang chủ <span class="gm-required">*</span></label>
                        <input type="text" name="homepage" class="gm-input"
                               placeholder="Trang chủ Game của bạn (vd: https://tengame.com)"
                               value="<?= e($_POST['homepage'] ?? '') ?>" required>
                    </div>

                    <div class="gm-form-row">
                        <label>Fanpage Hỗ trợ <span class="gm-required">*</span></label>
                        <input type="text" name="fanpage" class="gm-input"
                               placeholder="Trang fanpage của bạn (vd: https://www.facebook.com/...)"
                               value="<?= e($_POST['fanpage'] ?? '') ?>">
                    </div>
                </div>

                <!-- THÔNG TIN KỸ THUẬT -->
                <div class="gm-form-section">
                    <h2 class="gm-form-section-title">THÔNG TIN KỸ THUẬT *</h2>

                    <div class="gm-form-row gm-form-row-inline">
                        <div>
                            <label>Phiên bản <span class="gm-required">*</span></label>
                            <select name="version" class="gm-input" required>
                                <option value="">Chọn phiên bản</option>
                                <?php
                                $versions = ['Season 2','Season 6','Season 9','Season 12','Season 17','Khác'];
                                $cur = $_POST['version'] ?? '';
                                foreach ($versions as $v):
                                ?>
                                    <option value="<?= e($v) ?>" <?= $cur === $v ? 'selected' : '' ?>><?= e($v) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label>Kiểu reset <span class="gm-required">*</span></label>
                            <select name="reset_type" class="gm-input" required>
                                <option value="">Chọn kiểu reset</option>
                                <?php
                                $resets = ['Reset thường','Reset tích luỹ','Reset theo mốc','Không reset','Khác'];
                                $cur = $_POST['reset_type'] ?? '';
                                foreach ($resets as $v):
                                ?>
                                    <option value="<?= e($v) ?>" <?= $cur === $v ? 'selected' : '' ?>><?= e($v) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label>Thể loại <span class="gm-required">*</span></label>
                            <select name="category" class="gm-input" required>
                                <option value="">Chọn thể loại</option>
                                <?php
                                $cats = ['Game Reset','Game Không Reset','Event / Fun','Khác'];
                                $cur = $_POST['category'] ?? '';
                                foreach ($cats as $v):
                                ?>
                                    <option value="<?= e($v) ?>" <?= $cur === $v ? 'selected' : '' ?>><?= e($v) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label>Kiểu point <span class="gm-required">*</span></label>
                            <select name="point_type" class="gm-input" required>
                                <option value="">Chọn kiểu point</option>
                                <?php
                                $pts = ['5/7','10/12','20/20','Tự do','Khác'];
                                $cur = $_POST['point_type'] ?? '';
                                foreach ($pts as $v):
                                ?>
                                    <option value="<?= e($v) ?>" <?= $cur === $v ? 'selected' : '' ?>><?= e($v) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="gm-form-row">
                        <label>Tên Máy Chủ <span class="gm-required">*</span></label>
                        <input type="text" name="server_name" class="gm-input"
                               placeholder="Tên máy chủ Game (vd: máy chủ Lorenchia)"
                               value="<?= e($_POST['server_name'] ?? '') ?>" required>
                    </div>

                    <div class="gm-form-row">
                        <label>Miêu tả Game <span class="gm-required">*</span></label>
                        <input type="text" name="short_desc" class="gm-input"
                               placeholder="Miêu tả ngắn gọn (vd: Miễn phí 99%, không webshop, cày cuốc...)"
                               value="<?= e($_POST['short_desc'] ?? '') ?>" required>
                    </div>

                    <div class="gm-form-row gm-form-row-inline">
                        <div>
                            <label>Alpha Test <span class="gm-required">*</span> (giờ)</label>
                            <select name="alpha_time" class="gm-input">
                                <option value="">Giờ</option>
                                <?php
                                $hours = ['8h','9h','10h','11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h','22h','23h','24h'];
                                $curAlpha = $_POST['alpha_time'] ?? '';
                                foreach ($hours as $h):
                                ?>
                                    <option value="<?= e($h) ?>" <?= $curAlpha === $h ? 'selected' : '' ?>><?= e($h) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label>Alpha Test <span class="gm-required">*</span> (ngày)</label>
                            <input type="date" name="alpha_date" class="gm-input"
                                   value="<?= e($_POST['alpha_date'] ?? '') ?>">
                        </div>
                        <div>
                            <label>Open Beta <span class="gm-required">*</span> (giờ)</label>
                            <select name="open_time" class="gm-input">
                                <option value="">Giờ</option>
                                <?php
                                $hours = ['8h','9h','10h','11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h','22h','23h','24h'];
                                $curOpen = $_POST['open_time'] ?? '';
                                foreach ($hours as $h):
                                ?>
                                    <option value="<?= e($h) ?>" <?= $curOpen === $h ? 'selected' : '' ?>><?= e($h) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label>Open Beta <span class="gm-required">*</span> (ngày)</label>
                            <input type="date" name="open_date" class="gm-input"
                                   value="<?= e($_POST['open_date'] ?? '') ?>">
                        </div>
                    </div>

                    <div class="gm-form-row gm-form-row-inline">
                        <div>
                            <label>Exp <span class="gm-required">*</span></label>
                            <input type="text" name="exp_rate" class="gm-input"
                                   placeholder="Exp rate (vd: 1x, 5x, 100x, 500x, 9999x)"
                                   value="<?= e($_POST['exp_rate'] ?? '') ?>" required>
                        </div>
                        <div>
                            <label>Drop <span class="gm-required">*</span></label>
                            <input type="text" name="drop_rate" class="gm-input"
                                   placeholder="Drop rate (vd: 10%, 40%, 50%, 80%)"
                                   value="<?= e($_POST['drop_rate'] ?? '') ?>" required>
                        </div>
                        <div>
                            <label>Anti Hack <span class="gm-required">*</span></label>
                            <input type="text" name="anti_hack" class="gm-input"
                                   placeholder="Tên hệ thống anti-hack đang sử dụng (vd: GoldShield)"
                                   value="<?= e($_POST['anti_hack'] ?? '') ?>">
                        </div>
                    </div>
                </div>

                <!-- NỘI DUNG CHI TIẾT -->
                <div class="gm-form-section">
                    <h2 class="gm-form-section-title">NỘI DUNG CHI TIẾT *</h2>

                    <div class="gm-form-row">
                        <label>Miêu tả chi tiết game Game Online của bạn <span class="gm-required">*</span></label>
                        <textarea name="content" rows="8" class="gm-input gm-textarea"
                                  placeholder="Miêu tả chi tiết game Game Online của bạn (*): bài viết càng chi tiết sẽ càng thu hút nhiều người xem"><?= e($_POST['content'] ?? '') ?></textarea>
                    </div>
                </div>

                <!-- XÁC NHẬN -->
                <div class="gm-form-section">
                    <h2 class="gm-form-section-title">XÁC NHẬN</h2>

                    <div class="gm-form-row">
                        <label>Mã xác nhận (gõ GAME) <span class="gm-required">*</span></label>
                        <input type="text" name="captcha" class="gm-input"
                               placeholder="Nhập GAME để xác nhận"
                               value="<?= e($_POST['captcha'] ?? '') ?>" required>
                    </div>

                    <div class="gm-form-row">
                        <p class="gm-help">
                            <b>Quy định phí:</b><br>
                            - Tin thường: <b>MIỄN PHÍ</b>, cần Admin duyệt trước khi hiển thị.<br>
                            - Tin VIP: trừ <b><?= SUBMIT_COST_GOLD ?> GOLD</b>, hiển thị ngay sau khi gửi.
                        </p>
                    </div>

                    <div class="gm-form-actions">
                        <button type="submit" class="gm-btn-submit">
                            Đăng Game mới
                        </button>
                    </div>
                </div>

            </form>

        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . "/footer.php"; ?>
