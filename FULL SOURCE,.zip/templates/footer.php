<footer class="bg-light border-top mt-5 py-3">
    <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center">
        <div class="small text-muted">
            &copy; <?= date('Y') ?> Gamemoira.vn - Giải pháp Gamemoira Pro.
        </div>
        <div class="small">
            <a href="<?= BASE_URL ?>dieu-khoan" class="text-decoration-none me-2">Điều khoản</a>
            <a href="<?= BASE_URL ?>chinh-sach-bao-mat" class="text-decoration-none">Chính sách bảo mật</a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
