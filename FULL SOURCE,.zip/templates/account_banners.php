<?php
// templates/account_banners.php
// Quản lý banner + Thuê banner trừ GOLD

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bắt buộc đăng nhập + redirect lại đúng trang sau khi login
if (empty($_SESSION['user_id'])) {
    $redirect = BASE_URL . 'templates/account_banners.php';
    header('Location: ' . BASE_URL . 'templates/login.php?redirect=' . urlencode($redirect));
    exit;
}

$userId = (int)$_SESSION['user_id'];

$errors  = [];
$success = '';

// Lấy thông tin user hiện tại (để biết GOLD)
$stmtUser = $pdo->prepare("SELECT id, full_name, gold FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute([':id' => $userId]);
$currentUser = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$currentUser) {
    die('Không tìm thấy tài khoản.');
}

// Lấy cấu hình GOLD cho thuê banner
$bannerCostGold = (int) gm_get_setting('banner_cost_gold', 20);

// Xử lý thuê banner mới
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_banner') {
    $imageUrl = trim($_POST['image'] ?? '');
    $linkUrl  = trim($_POST['link']  ?? '');

    if ($imageUrl === '') {
        $errors[] = 'Vui lòng nhập link ảnh banner.';
    }
    if ($linkUrl === '') {
        $errors[] = 'Vui lòng nhập link khi click vào banner.';
    }
    if ($bannerCostGold <= 0) {
        $errors[] = 'Cài đặt GOLD cho thuê banner chưa được cấu hình.';
    }

    if (!$errors) {
        try {
            $pdo->beginTransaction();

            // Kiểm tra GOLD
            $stmtGold = $pdo->prepare("SELECT gold FROM users WHERE id = :id FOR UPDATE");
            $stmtGold->execute([':id' => $userId]);
            $rowGold = $stmtGold->fetch(PDO::FETCH_ASSOC);

            if (!$rowGold) {
                throw new Exception('Không tìm thấy tài khoản để trừ GOLD.');
            }

            $currentGold = (int)$rowGold['gold'];

            if ($currentGold < $bannerCostGold) {
                $pdo->rollBack();
                $errors[] = 'Bạn không đủ GOLD để thuê banner. Vui lòng nạp thêm GOLD.';
            } else {
                $newGold = $currentGold - $bannerCostGold;

                // Trừ GOLD
                $stmtUpdateGold = $pdo->prepare("UPDATE users SET gold = :g WHERE id = :id");
                $stmtUpdateGold->execute([
                    ':g'  => $newGold,
                    ':id' => $userId,
                ]);

                // Ghi giao dịch
                $stmtTran = $pdo->prepare("
                    INSERT INTO transactions (user_id, type, gold, note, created_at)
                    VALUES (:uid, :type, :gold, :note, NOW())
                ");
                $stmtTran->execute([
                    ':uid'  => $userId,
                    ':type' => 'rent_banner',
                    ':gold' => -$bannerCostGold,
                    ':note' => 'Thuê banner với ảnh: ' . $imageUrl,
                ]);

                // Tạo banner mới cho user
                // Bảng `banners` cần có cột: id, user_id, image, link, created_at (...)
                $stmtBanner = $pdo->prepare("
                    INSERT INTO banners (user_id, image, link, created_at)
                    VALUES (:uid, :image, :link, NOW())
                ");
                $stmtBanner->execute([
                    ':uid'   => $userId,
                    ':image' => $imageUrl,
                    ':link'  => $linkUrl,
                ]);

                $pdo->commit();

                $currentUser['gold'] = $newGold;
                $success = 'Thuê banner thành công. Bạn đã bị trừ ' . $bannerCostGold . ' GOLD.';
            }

        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'Không thể thuê banner: ' . $e->getMessage();
        }
    }
}

// Danh sách banner của user
$stmt = $pdo->prepare("
    SELECT id, image, link, created_at
    FROM banners
    WHERE user_id = :uid
    ORDER BY id DESC
");
$stmt->execute([':uid' => $userId]);
$banners = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle  = 'Quản lý banner';
$pageActive = 'banners';

require __DIR__ . '/header.php';
?>

<div class="gm-account-layout">

    <?php if (file_exists(__DIR__ . '/sidebar_account.php')): ?>
        <?php include __DIR__ . '/sidebar_account.php'; ?>
    <?php endif; ?>

    <div class="gm-account-content">
        <h2 class="gm-title">Quản lý banner</h2>

        <div class="gm-account-summary">
            <div>Xin chào, <strong><?= e($currentUser['full_name'] ?? '') ?></strong></div>
            <div>GOLD hiện có: <strong class="gm-gold"><?= (int)$currentUser['gold'] ?></strong></div>
            <div>Giá mỗi banner: <strong class="gm-gold"><?= (int)$bannerCostGold ?> GOLD</strong></div>
        </div>

        <?php if ($errors): ?>
            <div class="gm-alert gm-alert-danger">
                <?php foreach ($errors as $err): ?>
                    <div>- <?= e($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php elseif ($success): ?>
            <div class="gm-alert gm-alert-success">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <div class="gm-card">
            <h3 class="gm-card-title">Thuê banner mới</h3>
            <form method="post" action="" class="gm-form">
                <input type="hidden" name="action" value="create_banner">

                <div class="gm-form-row">
                    <label>Link ảnh banner (*):</label>
                    <input type="text" name="image" class="gm-input"
                           placeholder="https://... (ảnh .jpg, .png, .gif)"
                           value="<?= e($_POST['image'] ?? '') ?>">
                </div>

                <div class="gm-form-row">
                    <label>Link khi click vào banner (*):</label>
                    <input type="text" name="link" class="gm-input"
                           placeholder="https://trang-web-cua-ban.com"
                           value="<?= e($_POST['link'] ?? '') ?>">
                </div>

                <div class="gm-form-note">
                    Sau khi gửi, hệ thống sẽ trừ <strong><?= (int)$bannerCostGold ?> GOLD</strong> và tạo banner.
                    Admin có thể kiểm duyệt / chỉnh sửa thêm trong trang quản trị.
                </div>

                <div class="gm-form-footer">
                    <button type="submit" class="gm-btn-submit"
                            onclick="return confirm('Thuê banner mới và trừ <?= (int)$bannerCostGold ?> GOLD?');">
                        Thuê banner
                    </button>
                </div>
            </form>
        </div>

        <div class="gm-card">
            <h3 class="gm-card-title">Danh sách banner của bạn</h3>

            <?php if (empty($banners)): ?>
                <div class="gm-empty">Bạn chưa có banner nào.</div>
            <?php else: ?>
                <table class="gm-table gm-table-banners">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ảnh</th>
                        <th>Link</th>
                        <th>Ngày tạo</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($banners as $b): ?>
                        <tr>
                            <td>#<?= (int)$b['id'] ?></td>
                            <td>
                                <?php if (!empty($b['image'])): ?>
                                    <img src="<?= e($b['image']) ?>" alt="Banner" style="max-width:120px;max-height:60px;">
                                <?php endif; ?>
                            </td>
                            <td><?= e($b['link']) ?></td>
                            <td><?= e($b['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

    </div>
</div>

<?php require __DIR__ . '/footer.php'; ?>
