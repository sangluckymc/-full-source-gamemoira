// JS tùy biến dùng cho giao diện public
console.log('Gamemoira.vn loaded');
