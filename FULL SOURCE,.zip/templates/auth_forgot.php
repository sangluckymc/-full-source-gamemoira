<?php
// templates/auth_forgot.php

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Quên mật khẩu Gamemoira.vn';

// Nếu đã đăng nhập thì về trang chủ
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL);
    exit;
}

$errors     = [];
$success    = '';
$newPassStr = '';

function gm_post($key) {
    return trim($_POST[$key] ?? '');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone = gm_post('phone');

    if ($phone === '') {
        $errors[] = 'Vui lòng nhập số điện thoại.';
    }

    if (!$errors) {
        try {
            // Tìm user theo số điện thoại (nếu có cột phone)
            $user = null;
            try {
                $stmt = $pdo->prepare("
                    SELECT id, full_name, email 
                    FROM users 
                    WHERE phone = :phone 
                    LIMIT 1
                ");
                $stmt->execute([':phone' => $phone]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            } catch (Exception $e) {
                // Nếu không có cột phone, có thể muốn dùng email thay thế
                $stmt = $pdo->prepare("
                    SELECT id, full_name, email 
                    FROM users 
                    WHERE email = :phone
                    LIMIT 1
                ");
                $stmt->execute([':phone' => $phone]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            }

            // Tạo mật khẩu mới ngẫu nhiên (8 ký tự)
            if ($user) {
                $chars       = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
                $newPassword = '';
                for ($i = 0; $i < 8; $i++) {
                    $newPassword .= $chars[random_int(0, strlen($chars) - 1)];
                }

                $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);

                $stmtUpdate = $pdo->prepare("
                    UPDATE users 
                    SET password_hash = :hash
                    WHERE id = :id
                    LIMIT 1
                ");
                $stmtUpdate->execute([
                    ':hash' => $passwordHash,
                    ':id'   => $user['id'],
                ]);

                $newPassStr = $newPassword;
                $success    = 'Đã đặt lại mật khẩu thành công! Hãy dùng mật khẩu mới bên dưới để đăng nhập và đổi lại mật khẩu.';
            } else {
                // Không tìm thấy user nhưng vẫn trả về thông báo chung
                $success = 'Nếu số điện thoại tồn tại trong hệ thống, mật khẩu đã được đặt lại. Vui lòng liên hệ Admin nếu cần hỗ trợ thêm.';
            }

        } catch (Exception $e) {
            $errors[] = 'Lỗi hệ thống: ' . $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <title><?= e($pageTitle) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css?v=27">

    <style>
        body {
            background: #eef1f7;
            font-family: Arial, Helvetica, sans-serif;
        }
        .auth-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .auth-card {
            width: 100%;
            max-width: 420px;
            background: #ffffff;
            border-radius: 4px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.08);
            padding: 25px 30px 30px;
        }
        .auth-title {
            text-align: center;
            font-weight: 700;
            font-size: 18px;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .auth-form-group {
            margin-bottom: 12px;
        }
        .auth-input {
            width: 100%;
            border: 1px solid #d7dde5;
            border-radius: 3px;
            padding: 8px 10px;
            font-size: 14px;
        }
        .auth-input:focus {
            outline: none;
            border-color: #ff4b4b;
            box-shadow: 0 0 0 2px rgba(255,75,75,0.15);
        }
        .auth-btn-primary {
            width: 100%;
            border: none;
            border-radius: 3px;
            padding: 9px 12px;
            background: #ff4b4b;
            color: #fff;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            margin-top: 5px;
        }
        .auth-btn-primary:hover {
            background: #e33a3a;
        }
        .auth-btn-login {
            width: 100%;
            border: none;
            border-radius: 3px;
            padding: 9px 12px;
            background: #2ba84a;
            color: #fff;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            margin-top: 8px;
        }
        .auth-btn-login:hover {
            background: #248b3d;
        }
        .auth-divider-line {
            margin: 10px 0 4px;
            border-top: 1px solid #e2e5ec;
        }
        .auth-divider-text {
            text-align: center;
            color: #999;
            font-size: 12px;
            margin-bottom: 6px;
        }
        .auth-alert {
            font-size: 13px;
            padding: 8px 10px;
            border-radius: 3px;
            margin-bottom: 10px;
        }
        .auth-alert-danger {
            background: #ffe5e5;
            border: 1px solid #ff9a9a;
            color: #b52121;
        }
        .auth-alert-success {
            background: #e4ffea;
            border: 1px solid #8cd49e;
            color: #1b7a32;
        }
        .new-pass-box {
            margin-top: 8px;
            padding: 6px 10px;
            border-radius: 3px;
            background: #fffce2;
            border: 1px solid #f0d86a;
            font-size: 13px;
        }
        .new-pass-box b {
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="auth-page">
    <div class="auth-card">
        <div class="auth-title">Quên mật khẩu</div>

        <?php if ($errors): ?>
            <div class="auth-alert auth-alert-danger">
                <?php foreach ($errors as $err): ?>
                    <div>- <?= e($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php elseif ($success): ?>
            <div class="auth-alert auth-alert-success">
                <?= e($success) ?>
            </div>
            <?php if ($newPassStr): ?>
                <div class="new-pass-box">
                    Mật khẩu mới của bạn là: <b><?= e($newPassStr) ?></b><br>
                    Vui lòng đăng nhập và đổi lại mật khẩu để tăng bảo mật.
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <form method="post" action="">
            <div class="auth-form-group">
                <input type="text" name="phone" class="auth-input"
                       placeholder="Nhập số điện thoại"
                       value="<?= e($_POST['phone'] ?? '') ?>">
            </div>

            <button type="submit" class="auth-btn-primary">
                Lấy lại mật khẩu
            </button>
        </form>

        <div class="auth-divider-line"></div>
        <div class="auth-divider-text">hoặc</div>

        <form action="<?= BASE_URL ?>templates/login.php" method="get">
            <button type="submit" class="auth-btn-login">
                Đăng nhập
            </button>
        </form>
    </div>
</div>

</body>
</html>
