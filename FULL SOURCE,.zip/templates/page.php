<?php
$page = $GLOBALS['current_page_data'] ?? null;
if ($page) {
    $pageTitle = $page['title'];
    $metaDescription = $page['meta_description'] ?: mb_substr(strip_tags($page['content']), 0, 150);
}
?>

<div class="container my-4">
    <?php if (!$page): ?>
        <h1 class="h4">Trang không tồn tại</h1>
    <?php else: ?>
        <h1 class="h3 mb-3"><?= e($page['title']) ?></h1>
        <div class="page-content">
            <?= $page['content'] ?>
        </div>
    <?php endif; ?>
</div>
