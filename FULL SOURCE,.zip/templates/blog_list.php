<?php
$pageTitle = 'Blog / Tin tức';
$metaDescription = 'Blog, tin tức, kiến thức về Gamemoira Pro.';

$page = max(1, (int)($_GET['page'] ?? 1));
$limit = ITEMS_PER_PAGE;
$offset = ($page - 1) * $limit;

$category_id = isset($_GET['cat']) ? (int)$_GET['cat'] : null;

// Lấy danh mục để hiển thị filter
$cats = $pdo->query("SELECT * FROM categories ORDER BY sort_order, name")->fetchAll();

if ($category_id) {
    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM posts WHERE status='published' AND category_id = ?");
    $countStmt->execute([$category_id]);

    $stmt = $pdo->prepare("SELECT * FROM posts WHERE status='published' AND category_id = ?
                           ORDER BY published_at DESC, created_at DESC
                           LIMIT $limit OFFSET $offset");
    $stmt->execute([$category_id]);
} else {
    $countStmt = $pdo->query("SELECT COUNT(*) FROM posts WHERE status='published'");
    $stmt = $pdo->query("SELECT * FROM posts WHERE status='published'
                         ORDER BY published_at DESC, created_at DESC
                         LIMIT $limit OFFSET $offset");
}

$total = (int)$countStmt->fetchColumn();
$totalPages = max(1, ceil($total / $limit));
$posts = $stmt->fetchAll();
?>

<div class="container my-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h4 mb-0">Blog / Tin tức</h1>
        <small class="text-muted">Tổng: <?= $total ?> bài</small>
    </div>

    <!-- Lọc theo danh mục -->
    <form class="row g-2 mb-3" method="get" action="<?= BASE_URL ?>blog">
        <input type="hidden" name="route" value="blog">
        <div class="col-auto">
            <select name="cat" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">Tất cả danh mục</option>
                <?php foreach ($cats as $cat): ?>
                    <option value="<?= $cat['id'] ?>"
                        <?= $category_id == $cat['id'] ? 'selected' : '' ?>>
                        <?= e($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if ($category_id): ?>
            <div class="col-auto">
                <a href="<?= BASE_URL ?>blog" class="btn btn-sm btn-outline-secondary">Xóa lọc</a>
            </div>
        <?php endif; ?>
    </form>

    <?php if ($posts): ?>
        <?php foreach ($posts as $post): ?>
            <?php $url = BASE_URL . 'bai-viet/' . e($post['slug']) . '-' . $post['id']; ?>
            <article class="mb-3 pb-3 border-bottom">
                <h2 class="h5 mb-1">
                    <a href="<?= $url ?>" class="text-decoration-none">
                        <?= e($post['title']) ?>
                    </a>
                    <?php if ($post['type'] === 'vip'): ?>
                        <span class="badge bg-danger ms-1">VIP</span>
                    <?php endif; ?>
                </h2>
                <div class="text-muted small mb-1">
                    Ngày đăng: <?= date('d/m/Y', strtotime($post['published_at'] ?: $post['created_at'])) ?>
                </div>
                <?php if (!empty($post['excerpt'])): ?>
                    <p class="mb-1"><?= e($post['excerpt']) ?></p>
                <?php endif; ?>
                <a href="<?= $url ?>" class="small">Đọc tiếp &raquo;</a>
            </article>
        <?php endforeach; ?>

        <!-- Phân trang -->
        <?php if ($totalPages > 1): ?>
            <nav aria-label="Phân trang">
                <ul class="pagination pagination-sm">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                            <a class="page-link"
                               href="<?= BASE_URL ?>blog?page=<?= $i ?><?= $category_id ? '&cat=' . $category_id : '' ?>">
                                <?= $i ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>

    <?php else: ?>
        <p class="text-muted">Chưa có bài viết.</p>
    <?php endif; ?>
</div>
