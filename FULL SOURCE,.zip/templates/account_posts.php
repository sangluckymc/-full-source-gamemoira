<?php
// templates/account_posts.php
// Quản lý tin đăng + Đẩy TOP trừ GOLD

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bắt buộc đăng nhập + redirect lại đúng trang sau khi login
if (empty($_SESSION['user_id'])) {
    $redirect = BASE_URL . 'templates/account_posts.php';
    header('Location: ' . BASE_URL . 'templates/login.php?redirect=' . urlencode($redirect));
    exit;
}

$userId = (int)$_SESSION['user_id'];

$errors  = [];
$success = '';

// Lấy thông tin user hiện tại (để biết GOLD còn bao nhiêu)
$stmtUser = $pdo->prepare("SELECT id, full_name, gold FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute([':id' => $userId]);
$currentUser = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$currentUser) {
    die('Không tìm thấy tài khoản.');
}

// Lấy cấu hình GOLD cho chức năng ĐẨY TOP
$boostCostGold = (int) gm_get_setting('boost_cost_gold', 10);

// Xử lý ĐẨY TOP khi submit form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'boost') {
    $postId = (int)($_POST['post_id'] ?? 0);

    // Kiểm tra bài viết có thuộc về user không
    $stmtPost = $pdo->prepare("SELECT id, title, boosted_at FROM posts WHERE id = :pid AND user_id = :uid LIMIT 1");
    $stmtPost->execute([
        ':pid' => $postId,
        ':uid' => $userId,
    ]);
    $post = $stmtPost->fetch(PDO::FETCH_ASSOC);

    if (!$post) {
        $errors[] = 'Không tìm thấy tin đăng hoặc tin không thuộc về bạn.';
    } elseif ($boostCostGold <= 0) {
        $errors[] = 'Cài đặt GOLD cho chức năng đẩy top chưa được cấu hình.';
    } else {
        try {
            $pdo->beginTransaction();

            // Kiểm tra GOLD hiện tại
            $stmtGold = $pdo->prepare("SELECT gold FROM users WHERE id = :id FOR UPDATE");
            $stmtGold->execute([':id' => $userId]);
            $rowGold = $stmtGold->fetch(PDO::FETCH_ASSOC);

            if (!$rowGold) {
                throw new Exception('Không tìm thấy tài khoản để trừ GOLD.');
            }

            $currentGold = (int)$rowGold['gold'];

            if ($currentGold < $boostCostGold) {
                $pdo->rollBack();
                $errors[] = 'Bạn không đủ GOLD để đẩy top. Vui lòng nạp thêm GOLD.';
            } else {
                // Trừ GOLD
                $newGold = $currentGold - $boostCostGold;
                $stmtUpdateGold = $pdo->prepare("UPDATE users SET gold = :g WHERE id = :id");
                $stmtUpdateGold->execute([
                    ':g'  => $newGold,
                    ':id' => $userId,
                ]);

                // Ghi giao dịch
                $stmtTran = $pdo->prepare("
                    INSERT INTO transactions (user_id, type, gold, note, created_at)
                    VALUES (:uid, :type, :gold, :note, NOW())
                ");
                $stmtTran->execute([
                    ':uid'  => $userId,
                    ':type' => 'boost_post',
                    // ghi âm để dễ nhận biết giao dịch trừ GOLD
                    ':gold' => -$boostCostGold,
                    ':note' => 'Đẩy top tin #' . $postId . ' - ' . ($post['title'] ?? ''),
                ]);

                // Cập nhật thời gian đẩy top cho bài viết
                // CỘT `boosted_at` cần tồn tại trong bảng `posts` (DATETIME NULL)
                $stmtBoost = $pdo->prepare("
                    UPDATE posts
                    SET boosted_at = NOW(), updated_at = NOW()
                    WHERE id = :pid AND user_id = :uid
                ");
                $stmtBoost->execute([
                    ':pid' => $postId,
                    ':uid' => $userId,
                ]);

                $pdo->commit();

                // Cập nhật lại GOLD trên biến hiện tại để hiển thị đúng
                $currentUser['gold'] = $newGold;
                $success = 'Đẩy top tin #' . $postId . ' thành công. Bạn đã bị trừ ' . $boostCostGold . ' GOLD.';
            }

        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'Không thể đẩy top: ' . $e->getMessage();
        }
    }
}

// Lấy danh sách tin đăng của user
$stmt = $pdo->prepare("
    SELECT id, title, status, created_at, boosted_at
    FROM posts
    WHERE user_id = :uid
    ORDER BY COALESCE(boosted_at, created_at) DESC
");
$stmt->execute([':uid' => $userId]);
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle  = 'Quản lý tin đăng';
$pageActive = 'posts';

require __DIR__ . '/header.php';
?>

<div class="gm-account-layout">

    <?php if (file_exists(__DIR__ . '/sidebar_account.php')): ?>
        <?php include __DIR__ . '/sidebar_account.php'; ?>
    <?php endif; ?>

    <div class="gm-account-content">
        <h2 class="gm-title">Quản lý tin đăng</h2>

        <div class="gm-account-summary">
            <div>Xin chào, <strong><?= e($currentUser['full_name'] ?? '') ?></strong></div>
            <div>GOLD hiện có: <strong class="gm-gold"><?= (int)$currentUser['gold'] ?></strong></div>
            <div>Phí đẩy top mỗi lần: <strong class="gm-gold"><?= (int)$boostCostGold ?> GOLD</strong></div>
        </div>

        <?php if ($errors): ?>
            <div class="gm-alert gm-alert-danger">
                <?php foreach ($errors as $err): ?>
                    <div>- <?= e($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php elseif ($success): ?>
            <div class="gm-alert gm-alert-success">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <?php if (empty($posts)): ?>

            <div class="gm-empty">
                Bạn chưa có tin đăng nào.
            </div>

        <?php else: ?>

            <table class="gm-table gm-table-posts">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tiêu đề</th>
                    <th>Trạng thái</th>
                    <th>Ngày đăng</th>
                    <th>Đẩy top gần nhất</th>
                    <th>Hành động</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($posts as $p): ?>
                    <tr>
                        <td>#<?= (int)$p['id'] ?></td>
                        <td><?= e($p['title']) ?></td>
                        <td>
                            <?php if (($p['status'] ?? '') === 'published'): ?>
                                <span class="gm-badge gm-badge-success">Đang hiển thị</span>
                            <?php else: ?>
                                <span class="gm-badge gm-badge-muted">Nháp / Ẩn</span>
                            <?php endif; ?>
                        </td>
                        <td><?= e($p['created_at']) ?></td>
                        <td><?= e($p['boosted_at'] ?? '') ?></td>
                        <td>
                            <a class="gm-btn-small" href="post_detail.php?id=<?= (int)$p['id'] ?>" target="_blank">
                                Xem
                            </a>

                            <!-- Form đẩy top -->
                            <form method="post" action="" style="display:inline-block;margin-left:4px;"
                                  onsubmit="return confirm('Đẩy top tin này và trừ <?= (int)$boostCostGold ?> GOLD?');">
                                <input type="hidden" name="action" value="boost">
                                <input type="hidden" name="post_id" value="<?= (int)$p['id'] ?>">
                                <button type="submit" class="gm-btn-small gm-btn-gold">
                                    Đẩy top
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

        <?php endif; ?>

    </div>
</div>

<?php require __DIR__ . '/footer.php'; ?>
