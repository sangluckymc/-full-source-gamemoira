<?php
$post_id = (int)($_GET['post_id'] ?? 0);

$stmt = $pdo->prepare("SELECT p.*, c.name AS category_name FROM posts p
                       LEFT JOIN categories c ON p.category_id = c.id
                       WHERE p.id = ? AND p.status='published'");
$stmt->execute([$post_id]);
$post = $stmt->fetch();

if (!$post) {
    http_response_code(404);
    $pageTitle = 'Bài viết không tồn tại';
    $metaDescription = 'Bài viết bạn yêu cầu không tồn tại hoặc đã bị xóa.';
} else {
    $pageTitle = $post['title'];
    $metaDescription = $post['meta_description'] ?: mb_substr(strip_tags($post['excerpt'] ?: $post['content']), 0, 150);
}
?>

<div class="container my-4">
    <?php if (!$post): ?>
        <h1 class="h4">Bài viết không tồn tại</h1>
        <p class="text-muted">Liên kết bạn truy cập không còn hiệu lực.</p>
    <?php else: ?>
        <article>
            <h1 class="h3 mb-1"><?= e($post['title']) ?></h1>
            <div class="text-muted small mb-2">
                <?php if (!empty($post['category_name'])): ?>
                    <span class="me-2">Danh mục: <?= e($post['category_name']) ?></span>
                <?php endif; ?>
                <span>Ngày đăng: <?= date('d/m/Y', strtotime($post['published_at'] ?: $post['created_at'])) ?></span>
                <?php if ($post['type'] === 'vip'): ?>
                    <span class="badge bg-danger ms-2">VIP</span>
                <?php endif; ?>
            </div>

            <!-- Nút chia sẻ -->
            <div class="mb-3 small">
                <span class="me-2">Chia sẻ:</span>
                <?php $shareUrl = urlencode(BASE_URL . 'bai-viet/' . $post['slug'] . '-' . $post['id']); ?>
                <?php $shareText = urlencode($post['title']); ?>
                <a class="me-2" href="https://www.facebook.com/sharer/sharer.php?u=<?= $shareUrl ?>" target="_blank">Facebook</a>
                <a class="me-2" href="https://zalo.me/share?url=<?= $shareUrl ?>&text=<?= $shareText ?>" target="_blank">Zalo</a>
                <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= $shareUrl ?>" target="_blank">LinkedIn</a>
            </div>

            <div class="post-content">
                <?= $post['content'] ?>
            </div>
        </article>

        <!-- Bài viết liên quan -->
        <?php
        $relatedStmt = $pdo->prepare("SELECT id, title, slug FROM posts
                                      WHERE status='published' AND id <> ? AND category_id <=> ?
                                      ORDER BY published_at DESC, created_at DESC
                                      LIMIT 5");
        $relatedStmt->execute([$post['id'], $post['category_id']]);
        $related = $relatedStmt->fetchAll();
        ?>
        <?php if ($related): ?>
            <hr class="my-4">
            <h2 class="h6 mb-3">Bài viết liên quan</h2>
            <ul class="small">
                <?php foreach ($related as $r): ?>
                    <li>
                        <a href="<?= BASE_URL . 'bai-viet/' . e($r['slug']) . '-' . $r['id'] ?>">
                            <?= e($r['title']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    <?php endif; ?>
</div>
