<?php
$pageTitle        = 'Trang chủ';
$metaDescription  = 'Trang chủ Gamemoira.vn - Tin VIP và tin thường giới thiệu Gamemoira Pro.';

/* ============================
   LẤY DỮ LIỆU TỪ DATABASE
============================ */

/*
 * Thông tin kỹ thuật (server_name, version, alpha_date, open_date...)
 * nằm trong bảng game_submissions, cột post_id trỏ sang posts.id
 */

// Tin VIP
$vipStmt = $pdo->query("
    SELECT p.*,
           gs.server_name,
           gs.version,
           gs.alpha_date,
           gs.open_date,
           gs.alpha_time,
           gs.open_time
    FROM posts p
    LEFT JOIN game_submissions gs ON gs.post_id = p.id
    WHERE p.status = 'published'
      AND p.type   = 'vip'
    ORDER BY COALESCE(p.published_at, p.created_at) DESC
    LIMIT 50
");
$vipPosts = $vipStmt->fetchAll(PDO::FETCH_ASSOC);

// Tin thường
$normalStmt = $pdo->query("
    SELECT p.*,
           gs.server_name,
           gs.version,
           gs.alpha_date,
           gs.open_date,
           gs.alpha_time,
           gs.open_time
    FROM posts p
    LEFT JOIN game_submissions gs ON gs.post_id = p.id
    WHERE p.status = 'published'
      AND p.type   = 'thuong'
    ORDER BY COALESCE(p.published_at, p.created_at) DESC
    LIMIT 50
");
$normalPosts = $normalStmt->fetchAll(PDO::FETCH_ASSOC);

// Banner
$bannerStmt = $pdo->query("SELECT * FROM banners ORDER BY id ASC");
$allBanners = $bannerStmt->fetchAll(PDO::FETCH_ASSOC);

// Phân loại theo vị trí
$bannerLeft        = [];
$bannerRight       = [];
$bannerCenterBig   = [];
$bannerCenterSmall = [];

foreach ($allBanners as $b) {
    if (!isBannerActive($b)) {
        continue;
    }

    switch ($b['position']) {
        case 'left':
            $bannerLeft[] = $b;
            break;
        case 'right':
            $bannerRight[] = $b;
            break;
        case 'center':
        case 'center_big':
            $bannerCenterBig[] = $b;
            break;
        case 'center_small':
            $bannerCenterSmall[] = $b;
            break;
    }
}
?>

<div class="gm-layout-3col">

    <!-- ===== CỘT TRÁI ===== -->
    <aside class="gm-col-left">
        <?php foreach ($bannerLeft as $b): ?>
            <div class="gm-banner-side">
                <a href="<?= $b['link_url'] ? e($b['link_url']) : '#' ?>" target="_blank">
                    <img src="<?= BASE_URL . e($b['image_path']) ?>" alt="<?= e($b['title']) ?>">
                </a>
            </div>
        <?php endforeach; ?>
    </aside>

    <!-- ===== CỘT GIỮA ===== -->
    <main class="gm-col-center">

        <!-- ===== BANNER GIỮA ===== -->
        <?php foreach ($bannerCenterBig as $b): ?>
            <div class="gm-banner-center-big">
                <a href="<?= $b['link_url'] ? e($b['link_url']) : '#' ?>" target="_blank">
                    <img src="<?= BASE_URL . e($b['image_path']) ?>" alt="<?= e($b['title']) ?>">
                </a>
            </div>
        <?php endforeach; ?>

        <?php foreach ($bannerCenterSmall as $b): ?>
            <div class="gm-banner-center-small">
                <a href="<?= $b['link_url'] ? e($b['link_url']) : '#' ?>" target="_blank">
                    <img src="<?= BASE_URL . e($b['image_path']) ?>" alt="<?= e($b['title']) ?>">
                </a>
            </div>
        <?php endforeach; ?>

        <!-- ===== DANH SÁCH CHÍNH Ở GIỮA ===== -->
        <div class="gm-home-main-only">

            <!-- === DANH SÁCH GAME VIP === -->
            <div class="vip-list-wrapper">
                <div class="vip-list-title">
                    <div class="vip-list-title-left">
                        <span class="vip-list-dot">◆</span>
                        <span>Danh sách Game VIP</span>
                    </div>
                    <span class="vip-list-total">Tổng: <?= count($vipPosts) ?> tin</span>
                </div>

                <?php if ($vipPosts): ?>
                    <ul class="vip-list">
                        <?php $i = 1; foreach ($vipPosts as $post): ?>
                            <?php
                            $url   = BASE_URL . 'bai-viet/' . e($post['slug']) . '-' . $post['id'];
                            $thumb = $post['thumbnail'] ?? '';
                            ?>
                            <li class="vip-item">
                                <div class="vip-col-left">
                                    <div class="vip-index"><?= $i++ ?></div>
                                    <div class="vip-label">[Chi tiết MU]</div>
                                </div>

                                <div class="vip-col-center">
                                    <?php if ($thumb): ?>
                                        <div class="vip-banner">
                                            <a href="<?= $url ?>">
                                                <img src="<?= e($thumb) ?>" alt="<?= e($post['title']) ?>">
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <div class="vip-main-text">
                                        <div class="vip-title">
                                            <a href="<?= $url ?>"><?= e($post['title']) ?></a>
                                        </div>
                                        <?php if (!empty($post['excerpt'])): ?>
                                            <div class="vip-desc">
                                                <?= e($post['excerpt']) ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="vip-col-right">
                                    <div class="vip-badge">VIP VÀNG</div>
                                    <div class="vip-time">
                                        <strong>Ngày:</strong>
                                        <?= date('d/m/Y', strtotime($post['published_at'] ?: $post['created_at'])) ?>
                                    </div>
                                    <a href="<?= $url ?>" class="vip-detail-btn">Chi tiết MU</a>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="gm-subtext mb-0">Chưa có tin VIP.</p>
                <?php endif; ?>
            </div>

            <!-- === DANH SÁCH GAME MỚI RA MIỄN PHÍ HÔM NAY === -->
            <div class="today-wrapper">
                <div class="today-title">
                    <span class="today-dot">◆</span>
                    <span>Danh sách GAME mới ra miễn phí hôm nay</span>
                </div>

                <?php if ($normalPosts): ?>
                    <?php $i = 1; ?>
                    <?php foreach ($normalPosts as $post): ?>
                        <?php
                        $url = BASE_URL . 'bai-viet/' . e($post['slug']) . '-' . $post['id'];

                        // LABEL OPEN BETA ĐƠN GIẢN, KHÔNG DÙNG DateTime::diff
                        $openLabel = 'Open Beta: đang cập nhật';
                        if (!empty($post['open_date'])) {
                            $openLabel = 'Open Beta: ' . date('d/m/Y', strtotime($post['open_date']));
                        }
                        ?>
                        <div class="today-item">
                            <div class="today-stt"><?= $i++ ?></div>

                            <div class="today-main">
                                <div class="today-name">
                                    <a href="<?= $url ?>">— <?= e($post['title']) ?></a>
                                </div>
                                <div class="today-info">

                                    <?php if (!empty($post['server_name'])): ?>
                                        <div>- Server: <b><?= e($post['server_name']) ?></b></div>
                                    <?php endif; ?>

                                    <?php if (!empty($post['version'])): ?>
                                        <div>- Phiên bản: <b><?= e($post['version']) ?></b></div>
                                    <?php endif; ?>

                                    <?php if (!empty($post['alpha_date'])): ?>
                                        <div>- Alpha Test:
                                            <b><?= date('d/m/Y', strtotime($post['alpha_date'])) ?></b>
                                        </div>
                                    <?php endif; ?>

                                    <?php if (!empty($post['open_date'])): ?>
                                        <div>- Open Beta:
                                            <b class="today-open-highlight">
                                                <?= date('d/m/Y', strtotime($post['open_date'])) ?>
                                            </b>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="today-badge today-badge-normal">
                                <a href="<?= $url ?>"><?= e($openLabel) ?></a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="today-empty">Chưa có tin thường.</p>
                <?php endif; ?>
            </div>

            <!-- === DANH SÁCH TIN THƯỜNG === -->
            <div class="gm-block">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <h2 class="gm-section-title mb-0">Danh sách tin thường</h2>
                    <span class="gm-subtext">Tổng: <?= count($normalPosts) ?> tin</span>
                </div>

                <?php if ($normalPosts): ?>
                    <ul class="gm-list">
                        <?php $i = 1; foreach ($normalPosts as $post): ?>
                            <?php $url = BASE_URL . 'bai-viet/' . e($post['slug']) . '-' . $post['id']; ?>
                            <li class="gm-item">
                                <div class="gm-item-index">
                                    #<?= $i++ ?>
                                </div>
                                <div class="gm-item-main">
                                    <div class="gm-item-title">
                                        <a href="<?= $url ?>"><?= e($post['title']) ?></a>
                                        <span class="gm-badge-normal">Thường</span>
                                    </div>
                                    <div class="gm-item-meta">
                                        Ngày đăng:
                                        <?= date('d/m/Y', strtotime($post['published_at'] ?: $post['created_at'])) ?>
                                    </div>

                                    <?php if (!empty($post['excerpt'])): ?>
                                        <div class="gm-item-excerpt">
                                            <?= e($post['excerpt']) ?>
                                        </div>
                                    <?php endif; ?>

                                </div>
                                <div class="gm-item-actions">
                                    <a href="<?= $url ?>" class="gm-btn-detail">Chi tiết</a>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="gm-subtext mb-0">Chưa có tin thường.</p>
                <?php endif; ?>
            </div>

        </div><!-- /.gm-home-main-only -->
    </main>

    <!-- ===== CỘT PHẢI ===== -->
    <aside class="gm-col-right">
        <?php foreach ($bannerRight as $b): ?>
            <div class="gm-banner-side">
                <a href="<?= $b['link_url'] ? e($b['link_url']) : '#' ?>" target="_blank">
                    <img src="<?= BASE_URL . e($b['image_path']) ?>" alt="<?= e($b['title']) ?>">
                </a>
            </div>
        <?php endforeach; ?>
    </aside>

</div><!-- /.gm-layout-3col -->
