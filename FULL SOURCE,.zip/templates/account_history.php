<?php
// templates/account_history.php
// Lịch sử giao dịch GOLD + lọc theo thời gian

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bắt buộc đăng nhập + redirect lại đúng trang sau khi login
if (empty($_SESSION['user_id'])) {
    $redirect = BASE_URL . 'templates/account_history.php';
    header('Location: ' . BASE_URL . 'templates/login.php?redirect=' . urlencode($redirect));
    exit;
}

$userId = (int)$_SESSION['user_id'];

$errors  = [];
$success = '';

// Lấy thông tin user hiện tại (để hiển thị GOLD)
$stmtUser = $pdo->prepare("SELECT id, full_name, gold FROM users WHERE id = :id LIMIT 1");
$stmtUser->execute([':id' => $userId]);
$currentUser = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$currentUser) {
    die('Không tìm thấy tài khoản.');
}

// =============================
// LỌC THEO THỜI GIAN
// =============================

// Lấy tham số từ GET (dùng method GET để bấm F5 không bị gửi lại form)
$fromInput = trim($_GET['from'] ?? '');
$toInput   = trim($_GET['to']   ?? '');

// Nếu cả 2 đều trống -> mặc định 90 ngày gần nhất
if ($fromInput === '' && $toInput === '') {
    $defaultFrom = new DateTime('-90 days');
    $fromInput   = $defaultFrom->format('Y-m-d');
    $toInput     = date('Y-m-d');
}

// Chuẩn hóa from / to
$fromDateSql = null;
$toDateSql   = null;

if ($fromInput !== '') {
    // from 00:00:00
    $fromDateSql = $fromInput . ' 00:00:00';
}
if ($toInput !== '') {
    // to 23:59:59
    $toDateSql = $toInput . ' 23:59:59';
}

// =============================
// LẤY DỮ LIỆU GIAO DỊCH
// =============================

$sql = "
    SELECT id, type, gold, note, created_at
    FROM transactions
    WHERE user_id = :uid
";
$params = [':uid' => $userId];

if ($fromDateSql !== null) {
    $sql .= " AND created_at >= :from";
    $params[':from'] = $fromDateSql;
}
if ($toDateSql !== null) {
    $sql .= " AND created_at <= :to";
    $params[':to'] = $toDateSql;
}

$sql .= " ORDER BY id DESC LIMIT 300";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Mapping type -> nhãn
$typeLabels = [
    'deposit'      => 'Nạp GOLD',
    'boost_post'   => 'Đẩy top tin',
    'rent_banner'  => 'Thuê banner',
    'admin_adjust' => 'Điều chỉnh bởi Admin',
];

$pageTitle  = 'Lịch sử giao dịch GOLD';
$pageActive = 'history';

require __DIR__ . '/header.php';
?>

<style>
    .gm-account-summary {
        margin-bottom: 12px;
        padding: 10px 12px;
        border-radius: 10px;
        background: #020617;
        border: 1px solid #1e293b;
        color: #e5e7eb;
        font-size: 13px;
        display: flex;
        flex-wrap: wrap;
        gap: 10px 18px;
    }
    .gm-account-summary strong.gm-gold {
        color: #facc15;
    }
    .gm-filter-bar {
        margin-bottom: 10px;
        padding: 10px 12px;
        border-radius: 10px;
        background: #020617;
        border: 1px solid #1f2937;
        display: flex;
        flex-wrap: wrap;
        gap: 8px 12px;
        align-items: center;
        font-size: 13px;
        color: #e5e7eb;
    }
    .gm-filter-bar label {
        margin-right: 4px;
        font-size: 12px;
        color: #9ca3af;
    }
    .gm-filter-bar input[type="date"] {
        background: #020617;
        border: 1px solid #374151;
        color: #e5e7eb;
        border-radius: 6px;
        padding: 4px 8px;
        font-size: 13px;
    }
    .gm-filter-bar button {
        border-radius: 999px;
        border: 1px solid #0ea5e9;
        background: linear-gradient(to right, #0ea5e9, #6366f1);
        color: #e5e7eb;
        font-size: 12px;
        padding: 5px 12px;
        cursor: pointer;
    }
    .gm-filter-note {
        font-size: 11px;
        color: #9ca3af;
        margin-top: 2px;
    }
    .gm-history-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
        background: #020617;
        border-radius: 10px;
        overflow: hidden;
    }
    .gm-history-table th,
    .gm-history-table td {
        padding: 8px 10px;
        border-bottom: 1px solid #111827;
        text-align: left;
    }
    .gm-history-table thead {
        background: #020617;
    }
    .gm-history-table th {
        font-size: 11px;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        color: #9ca3af;
    }
    .gm-history-table tbody tr:nth-child(even) {
        background: #020617;
    }
    .gm-history-table tbody tr:hover {
        background: #111827;
    }
    .gm-gold-plus {
        color: #4ade80;
        font-weight: 600;
    }
    .gm-gold-minus {
        color: #f97373;
        font-weight: 600;
    }
    .gm-badge-type {
        display: inline-flex;
        align-items: center;
        padding: 2px 8px;
        border-radius: 999px;
        border: 1px solid #374151;
        font-size: 11px;
        color: #e5e7eb;
        background: #020617;
    }
    .gm-empty {
        padding: 14px 10px;
        font-size: 13px;
        color: #9ca3af;
        text-align: center;
        background: #020617;
        border-radius: 10px;
        border: 1px dashed #374151;
        margin-top: 10px;
    }
    .gm-alert {
        margin-bottom: 10px;
        padding: 8px 10px;
        border-radius: 8px;
        font-size: 13px;
    }
    .gm-alert-success {
        background: rgba(34,197,94,0.12);
        border: 1px solid rgba(34,197,94,0.5);
        color: #bbf7d0;
    }
    .gm-alert-danger {
        background: rgba(248,113,113,0.12);
        border: 1px solid rgba(248,113,113,0.5);
        color: #fecaca;
    }
</style>

<div class="gm-account-layout">

    <?php if (file_exists(__DIR__ . '/sidebar_account.php')): ?>
        <?php include __DIR__ . '/sidebar_account.php'; ?>
    <?php endif; ?>

    <div class="gm-account-content">
        <h2 class="gm-title">Lịch sử giao dịch GOLD</h2>

        <div class="gm-account-summary">
            <div>
                Xin chào, <strong><?= e($currentUser['full_name'] ?? '') ?></strong>
            </div>
            <div>
                GOLD hiện có:
                <strong class="gm-gold"><?= number_format((int)($currentUser['gold'] ?? 0)) ?></strong>
            </div>
            <div>
                Khoảng thời gian đang xem:
                <strong><?= e($fromInput) ?></strong>
                đến
                <strong><?= e($toInput) ?></strong>
            </div>
        </div>

        <?php if ($errors): ?>
            <div class="gm-alert gm-alert-danger">
                <?php foreach ($errors as $err): ?>
                    <div>- <?= e($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php elseif ($success): ?>
            <div class="gm-alert gm-alert-success">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <!-- FORM LỌC THỜI GIAN -->
        <form method="get" action="" class="gm-filter-bar">
            <div>
                <label for="from">Từ ngày:</label>
                <input type="date" id="from" name="from" value="<?= e($fromInput) ?>">
            </div>
            <div>
                <label for="to">Đến ngày:</label>
                <input type="date" id="to" name="to" value="<?= e($toInput) ?>">
            </div>
            <div>
                <button type="submit">Lọc</button>
                <div class="gm-filter-note">
                    Nếu bỏ trống cả 2 ô, hệ thống sẽ tự mặc định 90 ngày gần nhất.
                </div>
            </div>
        </form>

        <?php if (empty($rows)): ?>

            <div class="gm-empty">
                Không có giao dịch nào trong khoảng thời gian đã chọn.
            </div>

        <?php else: ?>

            <table class="gm-history-table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Loại giao dịch</th>
                    <th>Thay đổi GOLD</th>
                    <th>Ghi chú</th>
                    <th>Thời gian</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <?php
                    $goldChange = (int)$r['gold'];
                    $isPlus     = $goldChange > 0;
                    $label      = $typeLabels[$r['type']] ?? $r['type'];
                    ?>
                    <tr>
                        <td>#<?= (int)$r['id'] ?></td>
                        <td>
                            <span class="gm-badge-type">
                                <?= e($label) ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($isPlus): ?>
                                <span class="gm-gold-plus">+<?= number_format($goldChange) ?></span>
                            <?php else: ?>
                                <span class="gm-gold-minus"><?= number_format($goldChange) ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?= e($r['note'] ?? '') ?></td>
                        <td><?= e($r['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

        <?php endif; ?>

    </div>
</div>

<?php require __DIR__ . '/footer.php'; ?>
