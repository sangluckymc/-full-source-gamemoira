<?php
if (!isLoggedIn()) {
    redirect(BASE_URL . 'dang-nhap');
}
$pageTitle = 'Đổi mật khẩu';
$metaDescription = 'Đổi mật khẩu tài khoản của bạn.';

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password_old = $_POST['password_old'] ?? '';
    $password_new = $_POST['password_new'] ?? '';
    $password_new2 = $_POST['password_new2'] ?? '';

    if ($password_old === '' || $password_new === '' || $password_new2 === '') {
        $error = 'Vui lòng nhập đầy đủ thông tin.';
    } elseif ($password_new !== $password_new2) {
        $error = 'Mật khẩu mới nhập lại không khớp.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([currentUserId()]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password_old, $user['password_hash'])) {
            $error = 'Mật khẩu cũ không đúng.';
        } else {
            $hash = password_hash($password_new, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
            $stmt->execute([$hash, $user['id']]);
            $success = 'Đổi mật khẩu thành công.';
        }
    }
}
?>

<div class="container my-4">
    <h1 class="h4 mb-3">Đổi mật khẩu</h1>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= e($error) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?= e($success) ?></div>
    <?php endif; ?>

    <form method="post" class="col-md-6">
        <div class="mb-3">
            <label class="form-label">Mật khẩu hiện tại</label>
            <input type="password" name="password_old" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Mật khẩu mới</label>
            <input type="password" name="password_new" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Nhập lại mật khẩu mới</label>
            <input type="password" name="password_new2" class="form-control" required>
        </div>
        <button class="btn btn-primary">Đổi mật khẩu</button>
    </form>
</div>
