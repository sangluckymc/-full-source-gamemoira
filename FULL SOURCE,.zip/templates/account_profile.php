<?php
// templates/account_profile.php

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bắt buộc đăng nhập
if (empty($_SESSION['user_id'])) {
    $redirect = BASE_URL . 'templates/account_profile.php';
    header('Location: ' . BASE_URL . 'templates/login.php?redirect=' . urlencode($redirect));
    exit;
}

$userId = (int)$_SESSION['user_id'];

$errors  = [];
$success = '';

// Lấy thông tin user hiện tại
$stmt = $pdo->prepare("
    SELECT id, full_name, email, role, is_active, created_at
    FROM users
    WHERE id = :id
    LIMIT 1
");
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die('Không tìm thấy tài khoản.');
}

// Giá trị mặc định cho form
$full_name = $user['full_name'] ?? '';
$email     = $user['email'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name        = trim($_POST['full_name'] ?? '');
    $email            = trim($_POST['email'] ?? $email);
    $new_password     = $_POST['new_password'] ?? '';
    $password_confirm = $_POST['new_password_confirm'] ?? '';

    // Validate
    if ($full_name === '') {
        $errors[] = 'Vui lòng nhập họ tên hiển thị.';
    }

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email không hợp lệ.';
    }

    if ($new_password !== '' || $password_confirm !== '') {
        if (strlen($new_password) < 6) {
            $errors[] = 'Mật khẩu mới phải có ít nhất 6 ký tự.';
        }
        if ($new_password !== $password_confirm) {
            $errors[] = 'Mật khẩu nhập lại không khớp.';
        }
    }

    // Nếu không có lỗi thì cập nhật DB
    if (!$errors) {
        try {
            if ($new_password !== '') {
                $hash = password_hash($new_password, PASSWORD_BCRYPT);

                $sql = "
                    UPDATE users
                    SET full_name = :full_name,
                        email     = :email,
                        password  = :password
                    WHERE id = :id
                    LIMIT 1
                ";

                $params = [
                    ':full_name' => $full_name,
                    ':email'     => $email,
                    ':password'  => $hash,
                    ':id'        => $userId,
                ];
            } else {
                $sql = "
                    UPDATE users
                    SET full_name = :full_name,
                        email     = :email
                    WHERE id = :id
                    LIMIT 1
                ";

                $params = [
                    ':full_name' => $full_name,
                    ':email'     => $email,
                    ':id'        => $userId,
                ];
            }

            $updateStmt = $pdo->prepare($sql);
            $updateStmt->execute($params);

            // Cập nhật lại tên trong session để header, sidebar hiển thị đúng
            $_SESSION['user_name'] = $full_name;
            $success = 'Cập nhật thông tin tài khoản thành công.';

        } catch (Exception $e) {
            $errors[] = 'Có lỗi khi lưu dữ liệu: ' . $e->getMessage();
        }
    }
}

$pageTitle  = 'Thông tin tài khoản';
$pageActive = 'profile';

require __DIR__ . '/header.php';
?>

<div class="gm-account-layout">

    <?php include __DIR__ . '/sidebar_account.php'; ?>

    <div class="gm-account-content">
        <h2 class="gm-title">Thông tin tài khoản</h2>

        <?php if ($errors): ?>
            <div class="gm-alert gm-alert-danger">
                <?php foreach ($errors as $err): ?>
                    <div>- <?= e($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php elseif ($success): ?>
            <div class="gm-alert gm-alert-success">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <form method="post" action="" class="gm-form gm-form-account">

            <div class="gm-form-section-title">
                Thông tin cơ bản
            </div>

            <div class="gm-form-row">
                <label>Họ tên hiển thị (*):</label>
                <input type="text"
                       name="full_name"
                       class="gm-input"
                       value="<?= e($full_name) ?>"
                       required>
            </div>

            <div class="gm-form-row">
                <label>Email (không thay đổi):</label>
                <input type="email"
                       name="email"
                       class="gm-input"
                       value="<?= e($email) ?>"
                       readonly>
            </div>

            <div class="gm-form-row gm-form-row-2col">
                <div>
                    <label>Vai trò:</label>
                    <input type="text"
                           class="gm-input"
                           value="<?= e($user['role'] ?? '') ?>"
                           disabled>
                </div>
                <div>
                    <label>Ngày tạo tài khoản:</label>
                    <input type="text"
                           class="gm-input"
                           value="<?= e($user['created_at'] ?? '') ?>"
                           disabled>
                </div>
            </div>

            <div class="gm-form-section-title">
                Đổi mật khẩu (không bắt buộc)
            </div>

            <div class="gm-form-row gm-form-row-2col">
                <div>
                    <label>Mật khẩu mới:</label>
                    <input type="password"
                           name="new_password"
                           class="gm-input"
                           placeholder="Để trống nếu không đổi">
                </div>
                <div>
                    <label>Nhập lại mật khẩu mới:</label>
                    <input type="password"
                           name="new_password_confirm"
                           class="gm-input">
                </div>
            </div>

            <div class="gm-form-footer">
                <button type="submit" class="gm-btn-submit">
                    Lưu thay đổi
                </button>
            </div>

        </form>
    </div>

</div>

<?php require __DIR__ . '/footer.php'; ?>
