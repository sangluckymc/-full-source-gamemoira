<?php
// templates/auth_login.php

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Nếu đã đăng nhập thì chuyển hướng luôn
if (!empty($_SESSION['user_id'])) {
    $redirect = $_GET['redirect'] ?? BASE_URL;
    header("Location: " . $redirect);
    exit;
}

$errors   = [];
$success  = '';
$email    = '';
$password = '';

// URL sẽ redirect sau khi login thành công
$redirect = $_GET['redirect'] ?? BASE_URL;

// Xử lý đăng nhập
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Vui lòng nhập Email hợp lệ.';
    }
    if ($password === '') {
        $errors[] = 'Vui lòng nhập mật khẩu.';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare("
                SELECT id, full_name, email, password_hash, gold
                FROM users
                WHERE email = :email
                LIMIT 1
            ");
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // CHÚ Ý:
            // - Cột mật khẩu trong DB phải là `password_hash`
            // - Nếu anh đang dùng tên cột khác (vd: `password`) thì sửa lại cho khớp.
            if (!$user || !password_verify($password, $user['password_hash'])) {
                $errors[] = 'Email hoặc mật khẩu không đúng.';
            } else {
                // Login OK
                $_SESSION['user_id']    = (int)$user['id'];
                $_SESSION['user_name']  = $user['full_name'];
                $_SESSION['user_email'] = $user['email'];

                header("Location: " . $redirect);
                exit;
            }
        } catch (Exception $e) {
            $errors[] = 'Lỗi hệ thống: ' . $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <title>Đăng nhập</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS chung của site -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css?v=27">
    <style>
        body {
            background: #f3f6fb;
            font-family: Arial, Helvetica, sans-serif;
        }
        .auth-wrapper {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 15px;
        }
        .auth-card {
            width: 100%;
            max-width: 380px;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 6px 16px rgba(0,0,0,0.12);
            padding: 24px 24px 28px;
        }
        .auth-title {
            text-align: center;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 18px;
            text-transform: uppercase;
        }
        .auth-input {
            width: 100%;
            border-radius: 4px;
            border: 1px solid #d7dde5;
            padding: 9px 10px;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .auth-input:focus {
            outline: none;
            border-color: #2c89ff;
            box-shadow: 0 0 0 2px rgba(44,137,255,0.18);
        }
        .auth-btn-primary {
            width: 100%;
            border: none;
            border-radius: 4px;
            background: #ff3b2f;
            color: #fff;
            font-weight: 600;
            font-size: 14px;
            padding: 9px 12px;
            margin-top: 4px;
            margin-bottom: 10px;
            cursor: pointer;
        }
        .auth-btn-primary:hover {
            background: #e02e24;
        }
        .auth-btn-secondary {
            width: 100%;
            border: none;
            border-radius: 4px;
            background: #26a65b;
            color: #fff;
            font-weight: 600;
            font-size: 14px;
            padding: 9px 12px;
            cursor: pointer;
        }
        .auth-btn-secondary:hover {
            background: #1e894a;
        }
        .auth-or {
            text-align: center;
            font-size: 12px;
            color: #888;
            margin: 5px 0 8px;
        }
        .auth-bottom-link {
            font-size: 13px;
            text-align: center;
            margin-top: 4px;
        }
        .auth-bottom-link a {
            color: #2c89ff;
            text-decoration: none;
        }
        .auth-bottom-link a:hover {
            text-decoration: underline;
        }
        .auth-error {
            background: #ffe5e5;
            border: 1px solid #f5a8a8;
            color: #b20000;
            border-radius: 4px;
            padding: 8px 10px;
            font-size: 13px;
            margin-bottom: 10px;
        }
        .auth-success {
            background: #e4f8e7;
            border: 1px solid #8fd29a;
            color: #136b22;
            border-radius: 4px;
            padding: 8px 10px;
            font-size: 13px;
            margin-bottom: 10px;
        }
        .auth-top-links {
            text-align: center;
            font-size: 12px;
            margin-bottom: 6px;
        }
        .auth-top-links a {
            color: #2c89ff;
            text-decoration: none;
        }
        .auth-top-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="auth-wrapper">
    <div class="auth-card">
        <div class="auth-title">Đăng nhập</div>

        <?php if ($errors): ?>
            <div class="auth-error">
                <?php foreach ($errors as $err): ?>
                    <div>- <?= e($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="auth-success">
                <?= e($success) ?>
            </div>
        <?php endif; ?>

        <form method="post" action="">
            <input type="hidden" name="redirect" value="<?= e($redirect) ?>">

            <input
                type="email"
                name="email"
                class="auth-input"
                placeholder="Nhập địa chỉ Email"
                value="<?= e($email) ?>"
                required
            >

            <input
                type="password"
                name="password"
                class="auth-input"
                placeholder="Nhập mật khẩu"
                required
            >

            <button type="submit" class="auth-btn-primary">
                ĐĂNG NHẬP
            </button>
        </form>

        <div class="auth-top-links">
            <a href="auth_forgot.php">Quên mật khẩu?</a>
        </div>

        <div class="auth-or">hoặc</div>

        <form action="auth_register.php" method="get">
            <button type="submit" class="auth-btn-secondary">
                Đăng ký
            </button>
        </form>

        <div class="auth-bottom-link" style="margin-top:8px;">
            <a href="<?= BASE_URL ?>">← Quay về trang chủ</a>
        </div>
    </div>
</div>

</body>
</html>
