<?php
// logout.php – đặt trong public_html/templates/

// Nạp helper nếu cần dùng hàm e(), v.v.
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Xoá toàn bộ session hiện tại
$_SESSION = [];

// Nếu có dùng cookie session thì xoá luôn cookie (cho sạch)
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

session_destroy();

// Luôn quay về trang chủ domain hiện tại
// (không phụ thuộc BASE_URL để tránh lỗi constant)
$redirect = '/';

if (!empty($_GET['redirect'])) {
    // Chỉ cho phép redirect nội bộ (bắt đầu bằng /)
    $r = $_GET['redirect'];
    if (strpos($r, '/') === 0) {
        $redirect = $r;
    }
}

header('Location: ' . $redirect);
exit;
