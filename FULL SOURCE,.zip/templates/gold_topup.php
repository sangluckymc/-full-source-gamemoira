<?php
// templates/gold_topup.php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ====== HÀM ĐỌC CẤU HÌNH TỪ BẢNG settings (AN TOÀN, KHÔNG GHI ĐÈ HÀM KHÁC) ======
if (!function_exists('gm_get_setting')) {
    function gm_get_setting(PDO $pdo, string $key, string $default = '')
    {
        try {
            $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = :k LIMIT 1");
            $stmt->execute([':k' => $key]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && isset($row['setting_value'])) {
                return $row['setting_value'];
            }
        } catch (Exception $e) {
            // im lặng, dùng default
        }
        return $default;
    }
}

// ================== BẮT BUỘC ĐĂNG NHẬP ==================
if (empty($_SESSION['user_id'])) {
    $redirect = BASE_URL . 'templates/gold_topup.php';
    header('Location: ' . BASE_URL . 'templates/login.php?redirect=' . urlencode($redirect));
    exit;
}

$userId = (int)$_SESSION['user_id'];

// Lấy thông tin user
$headerUser = null;
try {
    $stmtHeaderUser = $pdo->prepare("SELECT id, full_name, gold FROM users WHERE id = :id LIMIT 1");
    $stmtHeaderUser->execute([':id' => $userId]);
    $headerUser = $stmtHeaderUser->fetch(PDO::FETCH_ASSOC) ?: null;
} catch (Exception $e) {
    $headerUser = null;
}

// ================== LẤY CẤU HÌNH NẠP GOLD TỪ settings ==================
$bankName      = gm_get_setting($pdo, 'gold_bank_name', 'VCB - Vietcombank');
$bankOwner     = gm_get_setting($pdo, 'gold_bank_owner', 'Nguyễn Văn A');
$bankAccount   = gm_get_setting($pdo, 'gold_bank_account', '0123456789');
$goldRateText  = gm_get_setting($pdo, 'gold_rate_text', '1.000 đ = 1 GOLD');
$bankQrUrl     = gm_get_setting($pdo, 'gold_qr_url', 'https://i.imgur.com/Cj9YxXK.png');
$goldNote1     = gm_get_setting($pdo, 'gold_note_1', 'Hãy quét mã QR để nạp tiền chính xác nhất.');
$goldNote2     = gm_get_setting($pdo, 'gold_note_2', 'Sau khi giao dịch thành công hệ thống sẽ tự động cộng GOLD sau 1-5 phút.');
$goldNote3     = gm_get_setting($pdo, 'gold_note_3', 'Nếu sau 15 phút chưa thấy cộng GOLD vui lòng liên hệ Admin.');

// ================== XỬ LÝ GỬI YÊU CẦU NẠP GOLD ==================
$errors     = [];
$successMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gold_request_submit'])) {
    $amountVnd       = (int)($_POST['amount_vnd'] ?? 0);
    $transferContent = trim($_POST['transfer_content'] ?? '');
    $note            = trim($_POST['note'] ?? '');

    if ($amountVnd <= 0) {
        $errors[] = 'Vui lòng nhập số tiền đã chuyển (VND).';
    }

    if ($transferContent === '') {
        $errors[] = 'Vui lòng nhập nội dung chuyển khoản đã dùng.';
    }

    if (!$errors) {
        // tạm tính GOLD dự kiến theo tỉ lệ 1.000đ = 1 GOLD
        $expectedGold = (int)floor($amountVnd / 1000);

        try {
            $stmt = $pdo->prepare("
                INSERT INTO gold_topups (user_id, amount_vnd, expected_gold, transfer_content, note, status, created_at)
                VALUES (:uid, :amount_vnd, :expected_gold, :content, :note, 'pending', NOW())
            ");
            $stmt->execute([
                ':uid'           => $userId,
                ':amount_vnd'    => $amountVnd,
                ':expected_gold' => $expectedGold,
                ':content'       => $transferContent,
                ':note'          => $note,
            ]);

            $successMsg = 'Yêu cầu nạp GOLD của bạn đã được gửi. Vui lòng đợi Admin kiểm tra và duyệt.';
        } catch (Exception $e) {
            $errors[] = 'Không thể tạo yêu cầu nạp GOLD: ' . $e->getMessage();
        }
    }
}

// ========= SEO + HEADER =========
$pageTitle  = 'Nạp GOLD vào tài khoản';
$pageActive = 'gold';

require __DIR__ . '/header.php';
?>

<div class="gm-account-layout">

    <?php include __DIR__ . '/sidebar_account.php'; ?>

    <div class="gm-account-content">

        <!-- Cột phải: phần tiêu đề + số dư giống mumoira -->
        <div class="gm-gold-topline">
            <div class="gm-gold-balance-box">
                <div class="gm-gold-balance-label">Số dư tài khoản:</div>
                <div class="gm-gold-balance-value">
                    <?= number_format((int)($headerUser['gold'] ?? 0)) ?> GOLD
                </div>
            </div>
            <a class="gm-gold-tab gm-gold-tab-active" href="#">
                <span class="icon">💳</span> Nạp GOLD vào tài khoản
            </a>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="gm-alert gm-alert-danger">
                <?php foreach ($errors as $err): ?>
                    <div>- <?= htmlspecialchars($err) ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if ($successMsg): ?>
            <div class="gm-alert gm-alert-success">
                <?= htmlspecialchars($successMsg) ?>
            </div>
        <?php endif; ?>

        <!-- CARD CHÍNH GIỐNG MUMOIRA -->
        <div class="gm-gold-maincard">

            <!-- header của card (tên ngân hàng + tỉ lệ nạp) -->
            <div class="gm-gold-maincard-header">
                <div class="gm-gold-bank-name">
                    <span class="gm-gold-bank-index">1 -</span>
                    <span class="gm-gold-bank-text"><?= htmlspecialchars($bankName) ?></span>
                </div>
                <div class="gm-gold-rate">
                    TỈ LỆ NẠP: <strong><?= htmlspecialchars($goldRateText) ?></strong>
                </div>
            </div>

            <div class="gm-gold-maincard-body">

                <!-- Cột QR + nội dung chuyển khoản -->
                <div class="gm-gold-main-left">

                    <div class="gm-gold-qr-block">
                        <div class="gm-gold-qr-bank-info">
                            <div><strong>Ngân hàng:</strong> <?= htmlspecialchars($bankName) ?></div>
                            <div><strong>Chủ TK:</strong> <?= htmlspecialchars($bankOwner) ?></div>
                            <div><strong>Số TK:</strong> <?= htmlspecialchars($bankAccount) ?></div>
                        </div>

                        <div class="gm-gold-qr-wrapper">
                            <img src="<?= htmlspecialchars($bankQrUrl) ?>"
                                 alt="QR nạp GOLD"
                                 class="gm-gold-qr-img">
                        </div>

                        <div class="gm-gold-qr-caption">
                            <small>Quét mã QR để nạp tiền chính xác nhất.</small>
                        </div>
                    </div>

                    <div class="gm-gold-notes-box">
                        <ul>
                            <li><?= htmlspecialchars($goldNote1) ?></li>
                            <li><?= htmlspecialchars($goldNote2) ?></li>
                            <li><?= htmlspecialchars($goldNote3) ?></li>
                        </ul>
                    </div>

                </div>

                <!-- Cột phải: form xác nhận + nội dung nạp -->
                <div class="gm-gold-main-right">

                    <div class="gm-gold-section-title">
                        Nhập đúng nội dung để tự động cộng GOLD:
                    </div>

                    <?php $refCode = 'mmr ' . (int)$userId; ?>

                    <input type="text"
                           class="gm-input gm-input-ref"
                           value="<?= htmlspecialchars($refCode) ?>"
                           readonly
                           onclick="this.select();">

                    <p class="gm-gold-small-note">
                        * Nội dung phải ghi chính xác: <strong><?= htmlspecialchars($refCode) ?></strong> (không thêm ký tự khác).
                    </p>

                    <form method="post" class="gm-gold-confirm-form">
                        <div class="gm-gold-form-row">
                            <label>Số tiền đã chuyển (VND)</label>
                            <input type="number"
                                   name="amount_vnd"
                                   class="gm-input"
                                   min="10000"
                                   step="1000"
                                   required
                                   placeholder="Ví dụ: 200000">
                        </div>

                        <div class="gm-gold-form-row">
                            <label>Nội dung chuyển khoản đã dùng</label>
                            <input type="text"
                                   name="transfer_content"
                                   class="gm-input"
                                   required
                                   value="<?= htmlspecialchars($refCode) ?>">
                        </div>

                        <div class="gm-gold-form-row">
                            <label>Ghi chú thêm (nếu có)</label>
                            <textarea name="note"
                                      class="gm-input"
                                      rows="3"
                                      placeholder="Ví dụ: Nạp lần 1 qua Vietcombank..."></textarea>
                        </div>

                        <button type="submit"
                                name="gold_request_submit"
                                value="1"
                                class="gm-btn-submit gm-btn-submit-primary">
                            Tôi đã chuyển khoản, gửi yêu cầu duyệt
                        </button>
                    </form>
                </div>

            </div><!-- /.gm-gold-maincard-body -->
        </div><!-- /.gm-gold-maincard -->

    </div><!-- /.gm-account-content -->
</div><!-- /.gm-account-layout -->

<?php require __DIR__ . '/footer.php'; ?>
