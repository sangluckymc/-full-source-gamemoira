<?php
$q = trim($_GET['q'] ?? '');
$pageTitle = 'Tìm kiếm: ' . $q;
$metaDescription = 'Kết quả tìm kiếm cho từ khóa: ' . $q;

$results = [];
if ($q !== '') {
    $like = '%' . $q . '%';
    $stmt = $pdo->prepare("
        SELECT * FROM posts
        WHERE status='published'
          AND (title LIKE ? OR content LIKE ? OR meta_description LIKE ?)
        ORDER BY published_at DESC, created_at DESC
        LIMIT 50
    ");
    $stmt->execute([$like, $like, $like]);
    $results = $stmt->fetchAll();
}
?>

<div class="container my-4">
    <h1 class="h4 mb-3">Kết quả tìm kiếm</h1>
    <form class="mb-3" method="get" action="<?= BASE_URL ?>tim-kiem">
        <input type="hidden" name="route" value="tim-kiem">
        <div class="input-group">
            <input type="text" class="form-control" name="q" value="<?= e($q) ?>" placeholder="Nhập từ khóa...">
            <button class="btn btn-outline-secondary" type="submit">Tìm</button>
        </div>
    </form>

    <?php if ($q === ''): ?>
        <p class="text-muted">Nhập từ khóa để tìm kiếm bài viết.</p>
    <?php else: ?>
        <p class="small text-muted mb-2">Từ khóa: <strong><?= e($q) ?></strong></p>
        <?php if ($results): ?>
            <?php foreach ($results as $post): ?>
                <?php $url = BASE_URL . 'bai-viet/' . e($post['slug']) . '-' . $post['id']; ?>
                <article class="mb-3 pb-3 border-bottom">
                    <h2 class="h6 mb-1">
                        <a href="<?= $url ?>" class="text-decoration-none">
                            <?= e($post['title']) ?>
                        </a>
                        <?php if ($post['type'] === 'vip'): ?>
                            <span class="badge bg-danger ms-1">VIP</span>
                        <?php endif; ?>
                    </h2>
                    <div class="text-muted small mb-1">
                        Ngày đăng: <?= date('d/m/Y', strtotime($post['published_at'] ?: $post['created_at'])) ?>
                    </div>
                    <?php if (!empty($post['excerpt'])): ?>
                        <p class="mb-1"><?= e($post['excerpt']) ?></p>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="text-muted">Không tìm thấy kết quả phù hợp.</p>
        <?php endif; ?>
    <?php endif; ?>
</div>
