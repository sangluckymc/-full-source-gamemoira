<?php
// templates/banner_info.php
// Trang thông tin thuê banner (public)

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle        = 'Thông tin thuê banner';
$metaDescription  = 'Thông tin quảng cáo banner tại Mu Mới Ra / Gamemoira.';

// Cấu hình số slot tối đa cho từng vị trí
define('SLOT_LEFT_MAX', 3);
define('SLOT_RIGHT_MAX', 3);
define('SLOT_CENTER_BIG_MAX', 1);
define('SLOT_CENTER_SMALL_MAX', 8);

// Lấy dữ liệu banner đang chạy
$now = new DateTime('now');

$stmt = $pdo->prepare("
    SELECT position, start_date, end_date, is_active
    FROM banners
    WHERE is_active = 1
");
$stmt->execute();
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Gom thống kê theo vị trí
$stats = [
    'left'   => ['count' => 0, 'next_end' => null],
    'right'  => ['count' => 0, 'next_end' => null],
    'center' => ['count' => 0, 'next_end' => null],
];

foreach ($rows as $r) {
    $pos = $r['position'] ?? 'center';
    if (!isset($stats[$pos])) {
        continue;
    }
    $stats[$pos]['count']++;

    if (!empty($r['end_date']) && $r['end_date'] !== '0000-00-00') {
        try {
            $end = new DateTime($r['end_date'] . ' 23:59:59');
            if ($end > $now) {
                if ($stats[$pos]['next_end'] === null || $end < $stats[$pos]['next_end']) {
                    $stats[$pos]['next_end'] = $end;
                }
            }
        } catch (Exception $e) {}
    }
}

// Tính dữ liệu cho từng box hiển thị
function gm_banner_box_data($position, $maxSlot, $stats, DateTime $now) {
    $countActive = $stats[$position]['count'] ?? 0;
    $nextEnd     = $stats[$position]['next_end'] ?? null;

    $slotsText   = $countActive . '/' . $maxSlot;

    // Nếu chưa full hoặc không có end_date => có thể thuê ngay
    if ($countActive < $maxSlot || $nextEnd === null || $nextEnd <= $now) {
        return [
            'slotsText' => $slotsText,
            'canRent'   => true,
            'freeAt'    => null,
        ];
    }

    return [
        'slotsText' => $slotsText,
        'canRent'   => false,
        'freeAt'    => $nextEnd->format('Y-m-d H:i:s'),
    ];
}

// Left / Right / Center tổng
$dataLeft   = gm_banner_box_data('left',   SLOT_LEFT_MAX,   $stats, $now);
$dataRight  = gm_banner_box_data('right',  SLOT_RIGHT_MAX,  $stats, $now);
$dataCenter = gm_banner_box_data('center', SLOT_CENTER_BIG_MAX + SLOT_CENTER_SMALL_MAX, $stats, $now);

// Cho dễ hiểu hơn: tách Center thành "Giữa To" + "Giữa Nhỏ"
$centerCount = $stats['center']['count'] ?? 0;

// Giữa To: tối đa 1 slot
$centerBigCount = min($centerCount, SLOT_CENTER_BIG_MAX);
$dataCenterBig  = [
    'slotsText' => $centerBigCount . '/' . SLOT_CENTER_BIG_MAX,
    'canRent'   => $centerBigCount < SLOT_CENTER_BIG_MAX,
    'freeAt'    => $stats['center']['next_end'] ? $stats['center']['next_end']->format('Y-m-d H:i:s') : null,
];

// Giữa Nhỏ: còn lại
$centerSmallCount = max($centerCount - SLOT_CENTER_BIG_MAX, 0);
$dataCenterSmall  = [
    'slotsText' => $centerSmallCount . '/' . SLOT_CENTER_SMALL_MAX,
    'canRent'   => $centerSmallCount < SLOT_CENTER_SMALL_MAX,
    'freeAt'    => $stats['center']['next_end'] ? $stats['center']['next_end']->format('Y-m-d H:i:s') : null,
];

require __DIR__ . '/header.php';
?>

<style>
.gm-banner-info-page {
    padding: 24px 0 40px;
    background: #e5ebf5;
}

.gm-banner-info-wrapper {
    max-width: 1040px;
    margin: 0 auto;
}

.gm-banner-info-title {
    text-align: center;
    font-weight: 700;
    font-size: 22px;
    margin-bottom: 22px;
    color: #111827;
}

.gm-banner-slot-row {
    display: grid;
    grid-template-columns: 1.1fr 1.4fr 1.1fr;
    gap: 24px;
    margin-bottom: 18px;
}

.gm-banner-slot-box {
    background: #002b3f;
    color: #ffe98a;
    border-radius: 4px;
    padding: 14px 18px;
    box-shadow: 0 3px 12px rgba(0, 0, 0, 0.35);
    font-size: 14px;
}

.gm-banner-slot-title {
    text-align: center;
    font-weight: 700;
    font-size: 18px;
    margin-bottom: 4px;
    color: #ffeb7f;
}

.gm-banner-slot-sub {
    text-align: center;
    font-size: 13px;
    margin-bottom: 12px;
    color: #e5e7eb;
}

.gm-banner-slot-meta {
    font-size: 13px;
    line-height: 1.5;
}

.gm-banner-slot-meta strong {
    color: #ffeb7f;
}

.gm-banner-slot-meta .label {
    display: inline-block;
    width: 120px;
}

.gm-banner-slot-countdown {
    margin-top: 10px;
    padding-top: 8px;
    border-top: 1px dashed rgba(255, 255, 255, 0.35);
    font-size: 13px;
}

.gm-banner-slot-countdown span.time {
    font-weight: 600;
}

.gm-banner-slot-countdown .status-green {
    color: #bbf7d0;
}

.gm-banner-slot-countdown .status-wait {
    color: #facc15;
}

.gm-banner-slot-small {
    margin-top: 12px;
    background: #fef3c7;
    color: #92400e;
    padding: 10px 14px;
    border-radius: 4px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
    font-size: 13px;
}

.gm-banner-slot-small .title {
    font-weight: 700;
    text-align: center;
    margin-bottom: 4px;
}

.gm-banner-slot-small .meta {
    line-height: 1.5;
}

.gm-banner-vip-section {
    margin-top: 26px;
    background: #fff;
    border-radius: 4px;
    padding: 18px 18px 10px;
    box-shadow: 0 4px 16px rgba(15,23,42,0.12);
    font-size: 14px;
}

.gm-banner-vip-title {
    font-weight: 600;
    margin-bottom: 10px;
}

.gm-banner-vip-box {
    margin-top: 8px;
    border-radius: 4px;
    overflow: hidden;
    border: 1px solid #fee2a2;
}

.gm-banner-vip-head {
    display: flex;
    justify-content: space-between;
    padding: 10px 14px;
    background: #fef3c7;
}

.gm-banner-vip-name {
    font-weight: 600;
}

.gm-banner-vip-meta {
    text-align: right;
    font-size: 13px;
}

.gm-banner-vip-body {
    padding: 12px 14px;
    background: #fffef5;
    font-size: 13px;
}

.gm-banner-text-block {
    margin-top: 30px;
    text-align: center;
    font-size: 13px;
    line-height: 1.7;
    color: #4b5563;
}

.gm-banner-text-block h2 {
    font-size: 18px;
    margin-bottom: 12px;
    font-weight: 700;
}
</style>

<div class="gm-banner-info-page">
    <div class="gm-banner-info-wrapper">

        <div class="gm-banner-info-title">
            Thông tin quảng cáo banner tại MU Mới Ra
        </div>

        <div class="gm-banner-slot-row">
            <!-- Banner trái -->
            <div class="gm-banner-slot-box">
                <div class="gm-banner-slot-title">Banner Trái</div>
                <div class="gm-banner-slot-sub">Kích thước: 210 x 400</div>
                <div class="gm-banner-slot-meta">
                    <div><span class="label">Số banner:</span> <strong><?= e($dataLeft['slotsText']) ?></strong></div>
                </div>
                <div class="gm-banner-slot-countdown"
                     data-countdown="<?= $dataLeft['freeAt'] ? e($dataLeft['freeAt']) : '' ?>">
                    <?php if ($dataLeft['canRent']): ?>
                        <span class="status-green">Hiện đang còn slot trống, có thể thuê ngay.</span>
                    <?php elseif ($dataLeft['freeAt']): ?>
                        Thời gian có slot: <span class="time js-time">Đang tính...</span>
                    <?php else: ?>
                        <span class="status-wait">Thời gian slot sẽ được cập nhật sau.</span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Banner giữa to + nhỏ -->
            <div class="gm-banner-slot-box">
                <div class="gm-banner-slot-title">Banner Giữa To</div>
                <div class="gm-banner-slot-sub">Kích thước: 780 x 280</div>
                <div class="gm-banner-slot-meta">
                    <div><span class="label">Số banner:</span> <strong><?= e($dataCenterBig['slotsText']) ?></strong></div>
                </div>
                <div class="gm-banner-slot-countdown"
                     data-countdown="<?= $dataCenterBig['freeAt'] ? e($dataCenterBig['freeAt']) : '' ?>">
                    <?php if ($dataCenterBig['canRent']): ?>
                        <span class="status-green">Hiện đang còn slot trống, có thể thuê ngay.</span>
                    <?php elseif ($dataCenterBig['freeAt']): ?>
                        Thời gian có slot: <span class="time js-time">Đang tính...</span>
                    <?php else: ?>
                        <span class="status-wait">Thời gian slot sẽ được cập nhật sau.</span>
                    <?php endif; ?>
                </div>

                <div class="gm-banner-slot-small">
                    <div class="title">Banner Giữa Nhỏ</div>
                    <div class="meta">
                        <div>Số banner: <strong><?= e($dataCenterSmall['slotsText']) ?></strong></div>
                        <div>Kích thước: <strong>780 x 110</strong></div>
                        <div class="mt-1"
                             data-countdown="<?= $dataCenterSmall['freeAt'] ? e($dataCenterSmall['freeAt']) : '' ?>">
                            <?php if ($dataCenterSmall['canRent']): ?>
                                <span class="status-green">Một số slot đang trống, có thể thuê ngay.</span>
                            <?php elseif ($dataCenterSmall['freeAt']): ?>
                                Thời gian có slot: <span class="time js-time">Đang tính...</span>
                            <?php else: ?>
                                <span class="status-wait">Thời gian slot sẽ được cập nhật sau.</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Banner phải -->
            <div class="gm-banner-slot-box">
                <div class="gm-banner-slot-title">Banner Phải</div>
                <div class="gm-banner-slot-sub">Kích thước: 210 x 400</div>
                <div class="gm-banner-slot-meta">
                    <div><span class="label">Số banner:</span> <strong><?= e($dataRight['slotsText']) ?></strong></div>
                </div>
                <div class="gm-banner-slot-countdown"
                     data-countdown="<?= $dataRight['freeAt'] ? e($dataRight['freeAt']) : '' ?>">
                    <?php if ($dataRight['canRent']): ?>
                        <span class="status-green">Hiện đang còn slot trống, có thể thuê ngay.</span>
                    <?php elseif ($dataRight['freeAt']): ?>
                        Thời gian có slot: <span class="time js-time">Đang tính...</span>
                    <?php else: ?>
                        <span class="status-wait">Thời gian slot sẽ được cập nhật sau.</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="gm-banner-vip-section">
            <div class="gm-banner-vip-title">Danh sách MU VIP (ví dụ minh hoạ)</div>
            <div class="gm-banner-vip-box">
                <div class="gm-banner-vip-head">
                    <div class="gm-banner-vip-name">Vip Vàng</div>
                    <div class="gm-banner-vip-meta">
                        <div>- Số Vip vàng: 26/30</div>
                        <div>- Kích thước: 780 x 110</div>
                    </div>
                </div>
                <div class="gm-banner-vip-body">
                    Nội dung tiêu đề và mô tả bài đăng quảng cáo MU Mới Ra, Vip Vàng... (anh có thể chỉnh sửa tuỳ ý).
                </div>
            </div>
        </div>

        <div class="gm-banner-text-block">
            <h2>Quảng cáo tại Mumoira.tv - MU Mới Ra hôm nay</h2>
            <p>
                Mumoira là nơi tập hợp những người đam mê cộng đồng game MU Online. Đặt banner tại đây giúp
                server của anh tiếp cận nhiều người chơi mới, tăng nhận diện thương hiệu và cộng đồng.
            </p>
            <p>
                Anh có thể liên hệ Admin để trao đổi thêm về giá, hình thức thanh toán và các gói ưu đãi.
            </p>
        </div>

    </div>
</div>

<script>
(function() {
    function initCountdown(el) {
        var target = el.getAttribute('data-countdown');
        if (!target) return;

        var timeSpan = el.querySelector('.js-time');
        if (!timeSpan) {
            timeSpan = document.createElement('span');
            timeSpan.className = 'time js-time';
            el.appendChild(timeSpan);
        }

        function pad(n) { return n < 10 ? '0' + n : n; }

        function tick() {
            var now   = new Date();
            var end   = new Date(target.replace(' ', 'T'));
            var diff  = end - now;

            if (diff <= 0) {
                timeSpan.textContent = 'Đã có thể thuê slot.';
                return;
            }
            var d  = Math.floor(diff / (1000 * 60 * 60 * 24));
            var hh = Math.floor((diff / (1000 * 60 * 60)) % 24);
            var mm = Math.floor((diff / (1000 * 60)) % 60);
            var ss = Math.floor((diff / 1000) % 60);
            timeSpan.textContent = d + ' Ngày ' + pad(hh) + ':' + pad(mm) + ':' + pad(ss);
        }

        tick();
        setInterval(tick, 1000);
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.gm-banner-slot-countdown, .gm-banner-slot-small [data-countdown]')
            .forEach(function(el) {
                initCountdown(el);
            });
    });
})();
</script>

<?php require __DIR__ . '/footer.php'; ?>
