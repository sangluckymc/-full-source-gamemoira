<?php
// templates/sidebar_account.php

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bắt buộc đăng nhập
if (empty($_SESSION['user_id'])) {
    // Quay lại đúng trang sau khi đăng nhập
    $currentUrl = $_SERVER['REQUEST_URI'] ?? BASE_URL;
    $loginUrl   = BASE_URL . 'templates/login.php?redirect=' . urlencode($currentUrl);
    header('Location: ' . $loginUrl);
    exit;
}

$userId = (int)$_SESSION['user_id'];

// Lấy thông tin user + GOLD từ DB
$stmt = $pdo->prepare("
    SELECT full_name, email, gold
    FROM users
    WHERE id = :id
    LIMIT 1
");
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Tên hiển thị
$displayName = $user['full_name'] ?? ($_SESSION['user_name'] ?? 'Tài khoản');

// Số GOLD hiện tại
$displayGold = isset($user['gold']) ? (int)$user['gold'] : 0;

// Xác định trang đang active (biến này set tại từng file nội dung: profile/gold/posts...)
$current = $pageActive ?? '';
?>

<aside class="gm-account-sidebar">

    <div class="gm-account-userbox">
        <div class="gm-user-avatar">👤</div>
        <div>
            <div class="gm-user-name"><?= e($displayName) ?></div>
            <div class="gm-user-gold"><?= $displayGold ?> GOLD</div>
        </div>
    </div>

    <nav class="gm-account-menu-list">
        <a class="gm-account-item <?= $current === 'profile' ? 'active' : '' ?>"
           href="account_profile.php">
            👤 Thông tin cá nhân
        </a>

        <a class="gm-account-item <?= $current === 'gold' ? 'active' : '' ?>"
           href="account_gold.php">
            💰 Nạp GOLD
        </a>

        <a class="gm-account-item <?= $current === 'posts' ? 'active' : '' ?>"
           href="account_posts.php">
            📝 Quản lý tin đăng
        </a>

        <a class="gm-account-item <?= $current === 'banners' ? 'active' : '' ?>"
           href="account_banners.php">
            🖼 Quản lý banner
        </a>

        <a class="gm-account-item <?= $current === 'history' ? 'active' : '' ?>"
           href="account_history.php">
            📄 Lịch sử giao dịch
        </a>

        <a class="gm-account-item logout"
           href="logout.php?redirect=<?= urlencode(BASE_URL) ?>">
            🚪 Đăng xuất
        </a>
    </nav>

</aside>
