<?php
// Kết nối DB + helper chung
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Lấy thông tin user cho menu tài khoản (GOLD thật)
$headerUser = null;
if (!empty($_SESSION['user_id'])) {
    try {
        $stmtHeaderUser = $pdo->prepare("
            SELECT id, full_name, gold
            FROM users
            WHERE id = :id
            LIMIT 1
        ");
        $stmtHeaderUser->execute([':id' => (int)$_SESSION['user_id']]);
        $headerUser = $stmtHeaderUser->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Exception $e) {
        $headerUser = null;
    }
}

// SEO cơ bản
if (!isset($pageTitle)) {
    $pageTitle = 'Gamemoira Pro';
}
if (!isset($metaDescription)) {
    $metaDescription = 'Gamemoira Pro - Website tổng hợp MU Online.';
}

// Lấy danh sách menu từ bảng `menus`
$menuItems = [];
try {
    $stmtMenu = $pdo->query("
        SELECT id, title, url, position, sort_order, is_active, is_highlight
        FROM menus
        WHERE is_active = 1
        ORDER BY sort_order ASC, id ASC
    ");
    $menuItems = $stmtMenu->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $menuItems = [];
}

// URL hiện tại để set active
$currentPath = $_SERVER['REQUEST_URI'] ?? '/';
$currentPath = parse_url($currentPath, PHP_URL_PATH);
$currentPath = rtrim($currentPath, '/');
if ($currentPath === '') {
    $currentPath = '/';
}
$currentUrl = $currentPath;

// Cấu hình đường dẫn trang đăng MU mới
$postPath = 'dang-bai'; // URL thân thiện cho trang đăng bài
$postUrl  = BASE_URL . ltrim($postPath, '/');

// Trang login public
$loginUrl = BASE_URL . 'templates/auth_login.php?redirect=' . urlencode($postUrl);
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <title><?= e($pageTitle) ?></title>
    <meta name="description" content="<?= e($metaDescription) ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css?v=27">
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>assets/logo/favicon.png">
</head>
<body>

<header class="gm-header">
    <div class="gm-topbar">
        <div class="gm-topbar-inner">

            <!-- LOGO -->
            <a href="<?= BASE_URL ?>" class="gm-logo">
                <img src="<?= BASE_URL ?>assets/logo/logo.png" alt="Gamemoira Pro">
            </a>

            <!-- MENU CHÍNH -->
            <nav class="gm-main-menu">
                <ul>
                    <?php if (!empty($menuItems)): ?>
                        <?php foreach ($menuItems as $item): ?>
                            <?php
                            $title = trim($item['title']);

                            // Ẩn mục ĐĂNG MU MỚI trong menus (sẽ có nút riêng màu đỏ)
                            if (mb_strtoupper($title, 'UTF-8') === 'ĐĂNG MU MỚI') {
                                continue;
                            }

                            $url = trim($item['url'] ?? '');
                            if ($url === '') {
                                continue;
                            }

                            // Loại bỏ BASE_URL nếu admin copy sẵn
                            $url = str_replace(['<?= BASE_URL ?>', '<?php echo BASE_URL; ?>'], '', $url);
                            $url = trim($url);

                            if (strpos($url, 'http://') === 0 || strpos($url, 'https://') === 0) {
                                $href = $url;
                            } else {
                                $href = BASE_URL . ltrim($url, '/');
                            }

                            $active   = '';
                            $pathOnly = parse_url($href, PHP_URL_PATH);
                            if ($pathOnly === '/' && $currentUrl === '/') {
                                $active = 'active';
                            } elseif ($pathOnly !== '/' && $pathOnly === $currentUrl) {
                                $active = 'active';
                            }
                            ?>
                            <li class="<?= $active ?>">
                                <a href="<?= e($href) ?>">
                                    <span class="gm-menu-dot">◆</span>
                                    <span><?= e($title) ?></span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <!-- Fallback nếu chưa có dữ liệu trong bảng menus -->
                        <li class="<?= ($currentUrl === '/' ? 'active' : '') ?>">
                            <a href="<?= BASE_URL ?>">
                                <span class="gm-menu-dot">◆</span>
                                <span>MU MỚI RA</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>

            <!-- KHU VỰC BÊN PHẢI (TÀI KHOẢN + NÚT ĐĂNG BÀI) -->
            <div class="gm-topbar-right">

                <?php if (!empty($_SESSION['user_id']) && $headerUser): ?>
                    <!-- DROPDOWN TÀI KHOẢN (dùng class gm-user-* đúng với CSS) -->
                    <div class="gm-user-dropdown">
                        <button type="button" class="gm-user-toggle">
                            <span class="gm-user-name"><?= e($headerUser['full_name']) ?></span>
                            <span class="gm-user-gold">
                                GOLD: <b><?= number_format((int)$headerUser['gold']) ?></b>
                            </span>
                            <span class="gm-user-caret">▼</span>
                        </button>

                        <div class="gm-user-menu">
                            <div class="gm-user-menu-header">
                                <div class="gm-user-menu-avatar">
                                    <?= mb_substr($headerUser['full_name'], 0, 1, 'UTF-8') ?>
                                </div>
                                <div class="gm-user-menu-info">
                                    <div class="gm-user-menu-name"><?= e($headerUser['full_name']) ?></div>
                                    <div class="gm-user-menu-gold">
                                        <span>GOLD hiện có:</span>
                                        <strong><?= number_format((int)$headerUser['gold']) ?></strong>
                                    </div>
                                </div>
                            </div>

                            <ul class="gm-user-menu-list">
                                <li>
                                    <a href="<?= BASE_URL ?>templates/account_profile.php">
                                        Xem trang cá nhân
                                    </a>
                                </li>
                                <li>
                                    <a href="<?= BASE_URL ?>templates/gold_topup.php">
                                        Nạp GOLD
                                    </a>
                                </li>
                                <li>
                                    <a href="<?= BASE_URL ?>templates/transactions.php">
                                        Giao dịch GOLD
                                    </a>
                                </li>
                                <li>
                                    <a href="<?= BASE_URL ?>templates/logout.php" class="gm-logout-link">
                                        Đăng xuất
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- CHƯA ĐĂNG NHẬP: hiện Đăng nhập / Đăng ký -->
                    <div class="gm-topbar-auth">
                        <a href="<?= BASE_URL ?>templates/auth_login.php" class="gm-auth-link">
                            Đăng nhập
                        </a>
                        <span class="gm-auth-sep">/</span>
                        <a href="<?= BASE_URL ?>templates/auth_register.php" class="gm-auth-link">
                            Đăng ký
                        </a>
                    </div>
                <?php endif; ?>

                <!-- Nút ĐĂNG MU MỚI màu đỏ -->
                <?php
                $targetPostUrl = !empty($_SESSION['user_id']) ? $postUrl : $loginUrl;
                ?>
                <a href="<?= e($targetPostUrl) ?>" class="gm-btn-post">
                    ĐĂNG MU MỚI
                </a>
            </div><!-- /.gm-topbar-right -->

        </div><!-- /.gm-topbar-inner -->
    </div><!-- /.gm-topbar -->
</header>

<main class="gm-main">
